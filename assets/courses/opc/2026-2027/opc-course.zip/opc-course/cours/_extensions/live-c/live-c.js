window.RevealLiveC = function () {
  return { id: "RevealLiveC", init(deck) {
    const dialog = document.createElement("dialog");
    dialog.className = "live-c-dialog";
    dialog.setAttribute("aria-label", "Live C example");
    dialog.innerHTML = `<header><strong id="live-title">Live C</strong><button type="button" data-close aria-label="Close live C">Close ×</button></header>
      <div class="live-c-toolbar"><button type="button" data-run>Compile &amp; run</button><button type="button" data-reload>Reload file</button><label>Run with <select data-mode aria-label="Execution mode"><option value="native">GCC only</option><option value="valgrind">Valgrind</option></select></label><span data-status role="status"></span></div>
      <div class="live-c-panes"><div><label>C source — editable</label><div id="live-source"></div></div><div><label for="live-stdin">Standard input</label><textarea id="live-stdin" spellcheck="false" placeholder="Input for scanf / fgets"></textarea><label for="live-result">Compiler and program output</label><pre id="live-result" aria-live="polite">No execution yet.</pre></div></div>
      <footer><code data-terminal></code><span>Ctrl+Enter: run · Esc: return to slides</span></footer>`;
    document.body.append(dialog);
    const source = LiveCEditor.create(dialog.querySelector("#live-source"), execute);
    const output = dialog.querySelector("#live-result");
    const status = dialog.querySelector("[data-status]");
    const run = dialog.querySelector("[data-run]");
    let example, token, trigger, previousKeyboard, originalSource, busy = false;
    const drafts = new Map();
    async function getFile() {
      const instructions = "For live C, run make present in the course folder, keep that terminal open, and visit http://127.0.0.1:8877/01-allocation.html in Firefox.";
      if (location.protocol === "file:") throw new Error(instructions);
      let response;
      try { response = await fetch(`/api/example/${encodeURIComponent(example)}`, {cache:"no-store"}); }
      catch { throw new Error(instructions); }
      if (!response.ok) throw new Error(instructions);
      const data = await response.json();
      token = data.token;
      source.setValue(data.source.replace(/^[ \t]*\/\/ slide:[^\n]*\n/gm, ""));
      originalSource = source.getValue();
      dialog.querySelector("[data-mode]").value = data.mode;
      dialog.querySelector("#live-stdin").value = data.stdin || "";
      dialog.querySelector("[data-terminal]").textContent = `cd demos/${example} && vim main.c  ·  make run / make valgrind`;
      status.textContent = "Ready — GCC on this machine";
      run.disabled = false;
    }
    async function execute() {
      if (busy || !token) return;
      busy = true; run.disabled = true; status.textContent = "Compiling and running…";
      output.textContent = ""; output.classList.remove("has-error");
      try {
        const response = await fetch("/api/run", {method:"POST", headers:{"Content-Type":"application/json", "X-Live-C-Token":token}, body:JSON.stringify({example, source:source.getValue(), stdin:dialog.querySelector("#live-stdin").value, mode:dialog.querySelector("[data-mode]").value})});
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Execution failed.");
        output.textContent = `$ ${data.command}\n\n${data.stdout}${data.stderr ? "\n"+data.stderr : ""}\n[exit ${data.returncode}]`;
        output.classList.toggle("has-error", data.returncode !== 0);
        status.textContent = data.returncode === 0 ? "Completed" : "Compiler / program returned an error";
      } catch(error) { output.textContent = error.message; status.textContent = "Execution unavailable"; }
      finally { busy = false; run.disabled = false; }
    }
    // Delegation survives Reveal/Quarto rebuilding slide DOM during startup.
    document.addEventListener("click", async event => {
      const button = event.target.closest("[data-live-example]");
      if (!button || busy) return;
      example = button.dataset.liveExample; trigger = button; token = null;
      previousKeyboard = deck.getConfig().keyboard;
      deck.configure({keyboard:false});
      dialog.querySelector("#live-title").textContent = `Live C · ${example}`;
      output.textContent = "No execution yet."; run.disabled = true;
      dialog.showModal();
      try { await getFile(); if(drafts.has(example)) source.setValue(drafts.get(example)); source.focus(); }
      catch(error) { status.textContent = "Presenter server required"; output.textContent=error.message; }
    });
    dialog.querySelector("[data-close]").onclick = () => dialog.close();
    dialog.addEventListener("close", () => { if(token) drafts.set(example,source.getValue()); deck.configure({keyboard:previousKeyboard}); trigger?.focus(); });
    dialog.querySelector("[data-reload]").onclick = async () => {
      if(busy) return;
      if(token && source.getValue() !== originalSource && !confirm("Reload the file from disk? This replaces the editor contents.")) return;
      try {await getFile();} catch(error){output.textContent=error.message;}
    };
    run.onclick = execute;
    dialog.addEventListener("keydown", event => {
      event.stopPropagation();
      if(!event.defaultPrevented && (event.ctrlKey || event.metaKey) && event.key === "Enter") {event.preventDefault(); execute();}
    });
  }};
};
