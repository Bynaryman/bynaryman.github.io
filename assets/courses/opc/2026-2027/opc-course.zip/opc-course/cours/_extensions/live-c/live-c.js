window.RevealLiveC = function () {
  return { id: "RevealLiveC", init(deck) {
    const dialog = document.createElement("dialog");
    dialog.className = "live-c-dialog";
    dialog.setAttribute("aria-label", "Live C example");
    dialog.innerHTML = `<header><strong id="live-title">Live C</strong><button type="button" data-close aria-label="Close live C">Close ×</button></header>
      <div class="live-c-toolbar"><button type="button" data-run>Compile &amp; run</button><button type="button" data-reload>Reload file</button><label data-step-label hidden>Step <select data-step aria-label="Example step"></select></label><label>Run with <select data-mode aria-label="Execution mode"><option value="native">GCC only</option><option value="valgrind">Valgrind</option></select></label><span data-status role="status"></span></div>
      <div class="live-c-panes"><div><label>C source — editable</label><div id="live-source"></div></div><div><label for="live-stdin">Standard input</label><textarea id="live-stdin" spellcheck="false" placeholder="Input for scanf / fgets"></textarea><label for="live-result">Compiler and program output</label><pre id="live-result" aria-live="polite">No execution yet.</pre></div></div>
      <footer><code data-terminal></code><span>Ctrl+Enter: run · Esc: return to slides</span></footer>`;
    document.body.append(dialog);
    const source = LiveCEditor.create(dialog.querySelector("#live-source"), execute);
    const output = dialog.querySelector("#live-result");
    const status = dialog.querySelector("[data-status]");
    const run = dialog.querySelector("[data-run]");
    let example, stage = "", token, trigger, previousKeyboard, originalSource, busy = false, loading = false;
    const steps = dialog.querySelector("[data-step]");
    const mode = dialog.querySelector("[data-mode]");
    const input = dialog.querySelector("#live-stdin");
    const drafts = new Map();
    function saveDraft() {
      if (token) drafts.set(`${example}/${stage}`, {source: source.getValue(), stdin: input.value, mode: mode.value});
    }
    async function getFile(requested = stage, restore = true) {
      loading = true; token = null; run.disabled = true; steps.disabled = true;
      try {
        const instructions = "For live C, run make present in the course folder, keep that terminal open, and visit http://127.0.0.1:8877/01-allocation.html in Firefox.";
        if (location.protocol === "file:") throw new Error(instructions);
        let response;
        try { response = await fetch(`/api/example/${encodeURIComponent(example)}?stage=${encodeURIComponent(requested)}`, {cache:"no-store"}); }
        catch { throw new Error(instructions); }
        if (!response.ok) throw new Error(instructions);
        const data = await response.json();
        token = data.token;
        stage = data.stage || "";
        steps.replaceChildren();
        for (const item of data.stages || []) {
          const option = document.createElement("option");
          option.value = item.id; option.textContent = item.label;
          steps.append(option);
        }
        steps.value = stage;
        dialog.querySelector("[data-step-label]").hidden = !steps.options.length;
        source.setValue(data.source.replace(/^[ \t]*\/\/ slide:[^\n]*\n/gm, ""));
        originalSource = source.getValue();
        mode.value = data.mode;
        input.value = data.stdin || "";
        const draft = restore && drafts.get(`${example}/${stage}`);
        if (draft) { source.setValue(draft.source); input.value = draft.stdin; mode.value = draft.mode; }
        output.textContent = "No execution yet.";
        output.classList.remove("has-error");
        dialog.querySelector("[data-terminal]").textContent = `demos/${example}/${data.file || "main.c"}`;
        status.textContent = "Ready — GCC on this machine";
        run.disabled = false;
      } finally { loading = false; steps.disabled = false; }
    }
    async function execute() {
      if (busy || loading || !token) return;
      busy = true; run.disabled = true; steps.disabled = true; status.textContent = "Compiling and running…";
      output.textContent = ""; output.classList.remove("has-error");
      try {
        const response = await fetch("/api/run", {method:"POST", headers:{"Content-Type":"application/json", "X-Live-C-Token":token}, body:JSON.stringify({example, source:source.getValue(), stdin:dialog.querySelector("#live-stdin").value, mode:dialog.querySelector("[data-mode]").value})});
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Execution failed.");
        output.textContent = `$ ${data.command}\n\n${data.stdout}${data.stderr ? "\n"+data.stderr : ""}\n[exit ${data.returncode}]`;
        output.classList.toggle("has-error", data.returncode !== 0);
        status.textContent = data.returncode === 0 ? "Completed" : "Compiler / program returned an error";
      } catch(error) { output.textContent = error.message; status.textContent = "Execution unavailable"; }
      finally { busy = false; run.disabled = false; steps.disabled = false; }
    }
    // Delegation survives Reveal/Quarto rebuilding slide DOM during startup.
    document.addEventListener("click", async event => {
      const button = event.target.closest("[data-live-example]");
      if (!button || busy || loading) return;
      example = button.dataset.liveExample; stage = button.dataset.liveStage || ""; trigger = button; token = null;
      previousKeyboard = deck.getConfig().keyboard;
      deck.configure({keyboard:false});
      dialog.querySelector("#live-title").textContent = `Live C · ${example}`;
      output.textContent = "No execution yet."; run.disabled = true;
      dialog.showModal();
      try { await getFile(); source.focus(); }
      catch(error) { status.textContent = "Presenter server required"; output.textContent=error.message; }
    });
    dialog.querySelector("[data-close]").onclick = () => dialog.close();
    dialog.addEventListener("close", () => { saveDraft(); deck.configure({keyboard:previousKeyboard}); trigger?.focus(); });
    dialog.querySelector("[data-reload]").onclick = async () => {
      if(busy || loading) return;
      if(token && source.getValue() !== originalSource && !confirm("Reload the file from disk? This replaces the editor contents.")) return;
      try {await getFile(stage, false); drafts.delete(`${example}/${stage}`);} catch(error){output.textContent=error.message;}
    };
    steps.onchange = async () => {
      const requested = steps.value;
      if (busy || loading) { steps.value = stage; return; }
      saveDraft();
      try { await getFile(requested); source.focus(); }
      catch (error) { output.textContent = error.message; status.textContent = "Step unavailable"; }
    };
    run.onclick = execute;
    dialog.addEventListener("keydown", event => {
      event.stopPropagation();
      if(!event.defaultPrevented && (event.ctrlKey || event.metaKey) && event.key === "Enter") {event.preventDefault(); execute();}
    });
  }};
};
