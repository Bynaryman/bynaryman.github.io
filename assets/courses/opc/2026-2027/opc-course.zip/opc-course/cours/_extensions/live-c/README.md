# Live C · Quarto Reveal.js extension

This is a repository-local Reveal.js plugin packaged using Quarto's normal
extension mechanism. It is not a Firefox extension and needs no browser install.

`_extension.yml` registers the `RevealLiveC` plugin and its assets:

```yaml
contributes:
  revealjs-plugins:
    - name: RevealLiveC
      script:
        - editor.bundle.js
        - live-c.js
      stylesheet: live-c.css
```

The project enables the extension in `cours/_quarto.yml`:

```yaml
revealjs-plugins:
  - live-c
```

To attach a runnable example to a slide:

```markdown
::: {.demo example="04-array"}
:::
```

`cours/filters/examples.lua` turns this block into a button in Reveal and a source
file reference in Beamer. The JS opens the editor, reads `demos/allocation/09-array.c`
from the local Python presenter, and sends the edited source back for a real
GCC compile/run. GCC alone and Valgrind are the lecture choices. ASan/UBSan are
additional developer checks, intentionally absent from the lecture controls.

## Use

From the repository root, run `make present` and keep that terminal open.
Open `http://127.0.0.1:8877/01-allocation.html` in Firefox. `make serve` skips the
render if the HTML already exists; Ctrl+C stops the server. Direct file opening
works for static slides, with a clear launcher message if live C is requested.
No executable files need to be managed manually.

The CodeMirror editor supports C highlighting, line numbers, bracket matching,
indentation with Tab / Shift+Tab, undo/redo, and Ctrl+Enter (Cmd+Enter on macOS)
to compile and run. Escape returns to the slides. Browser edits remain temporary;
edit the `.c` file for a permanent change. The colours use the deck's white
background and contrasting blue/green/purple/red accents.

## Saved steps

An example folder may include `steps.json`, listing each step's `id`, `label`,
relative C `file`, execution `mode`, and default `stdin`. The presenter exposes
only those declared steps. The editor's Step menu keeps a separate draft for
each step, including input and execution mode.

A slide can open a particular step:

```markdown
::: {.demo example="allocation" step="04-free"}
:::
```

The allocation sequence uses `main.c` for step `01-array`, then
`<step>.c`. The PDF includes the selected source path.

## Rebuild the editor bundle (developers only)

```sh
npm --prefix scripts/live-c-editor ci
npm --prefix scripts/live-c-editor run build
```

Source: `scripts/live-c-editor/editor.js`. The lockfile pins dependencies.
The build emits `editor.bundle.js` and `editor.LICENSE.txt`, both committed.
Quarto includes the local bundle; no npm install or CDN is needed to present.
The bundle contains CodeMirror and its C stream parser, not a C compiler.

References: [Quarto Reveal plugins](https://quarto.org/docs/extensions/revealjs.html),
[CodeMirror](https://codemirror.net/).
