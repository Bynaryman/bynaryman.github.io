-- Include code from the compiled examples. One source for slides and demos.
function CodeBlock(block)
  local source = block.attributes["file"]
  if not source then return nil end
  local f = assert(io.open(source, "r"), "Cannot open " .. source)
  local text = f:read("*a")
  f:close()
  local region = block.attributes["region"]
  if region then
    local first = "// slide:" .. region .. ":begin\n"
    local last = "// slide:" .. region .. ":end"
    local a, b = text:find(first, 1, true)
    assert(a, "Missing region " .. region .. " in " .. source)
    local z = assert(text:find(last, b + 1, true))
    text = text:sub(b + 1, z - 1):gsub("\n%s*$", "")
    -- Regions are indented uniformly when inside a C function.
    local indent = text:match("^( +)")
    if indent then text = text:gsub("^" .. indent, ""):gsub("\n" .. indent, "\n") end
  end
  block.text = text:gsub("\n$", "")
  block.attributes["file"] = nil
  block.attributes["region"] = nil
  return block
end

function Image(image)
  if FORMAT:match("revealjs") and image.src:match("^assets/diagrams/.*%.svg$") then
    local file = assert(io.open(image.src, "rb"), "Cannot open " .. image.src)
    local contents = file:read("*a")
    file:close()
    image.src = image.src .. "?v=" .. pandoc.utils.sha1(contents):sub(1, 12)
  end
  if FORMAT:match("beamer") and image.src:match("%.svg$") then
    image.src = image.src:gsub("%.svg$", ".pdf")
    -- Every TikZ figure has the same 22 cm canvas and label size. Keep that
    -- common scale in print as well, rather than forcing equal image heights.
    image.attributes.width = image.classes:includes("quiz-diagram") and "80%" or "100%"
  end
  return image
end

-- Explicit column widths make LaTeX wrap table cells instead of overflowing.
function Table(tbl)
  if #tbl.colspecs == 2 then
    tbl.colspecs[1][2] = 0.36
    tbl.colspecs[2][2] = 0.64
  elseif #tbl.colspecs == 3 then
    tbl.colspecs[1][2] = 0.44
    tbl.colspecs[2][2] = 0.26
    tbl.colspecs[3][2] = 0.30
  end
  return tbl
end

function Div(div)
  if div.classes:includes("diagram-swap") then
    assert(#div.content == 2, "A diagram swap needs a before and an after diagram")
    if FORMAT:match("revealjs") then
      div.classes:insert("r-stack")
      for i, state in ipairs(div.content) do
        assert(state.t == "Div", "Diagram states must be Divs")
        state.classes:insert("fragment")
        if i == 1 then state.classes:insert("fade-out") end
        state.attributes["data-fragment-index"] = "0"
      end
      return div
    end
    -- The handout keeps the completed state, without overlaying both diagrams.
    return div.content[2]
  end
  if FORMAT:match("beamer") and div.classes:includes("call-trace") then
    return {
      pandoc.RawBlock("latex", "\\begingroup\\CallTraceLayout"),
      div,
      pandoc.RawBlock("latex", "\\endgroup")
    }
  end
  if FORMAT:match("beamer") and div.classes:includes("quiz-layout") then
    return {
      pandoc.RawBlock("latex", "\\begingroup\\KahootLayout"),
      div,
      pandoc.RawBlock("latex", "\\endgroup")
    }
  end
  if FORMAT:match("beamer") and div.classes:includes("quiz-explanation") then
    div.content:insert(1, pandoc.RawBlock("latex", "\\vspace{3mm}{\\fontsize{8.5}{10}\\selectfont"))
    div.content:insert(pandoc.RawBlock("latex", "\\par}"))
    return div
  end
  if FORMAT:match("beamer") and (div.classes:includes("photo-credit") or div.classes:includes("photo-caption") or div.classes:includes("bio-link")) then
    local size = div.classes:includes("photo-credit") and "\\scriptsize" or "\\small"
    div.content:insert(1, pandoc.RawBlock("latex", "{" .. size))
    div.content:insert(pandoc.RawBlock("latex", "\\par}"))
    return div
  end
  if FORMAT:match("beamer") and div.classes:includes("lesson-flow") then
    return div:walk({ Header = function(header)
      if header.level ~= 3 then return nil end
      return pandoc.Div({
        pandoc.RawBlock("latex", "{\\color{CourseBlue}\\large\\bfseries"),
        pandoc.Para(header.content),
        pandoc.RawBlock("latex", "\\par}\\vspace{2mm}")
      })
    end })
  end
  if FORMAT:match("beamer") and div.classes:includes("step-result") then
    local colour = div.classes:includes("red") and "CourseRed" or "CourseGreen"
    div.content:insert(1, pandoc.RawBlock("latex", "\\vspace{2mm}{\\color{" .. colour .. "}\\large"))
    div.content:insert(pandoc.RawBlock("latex", "\\par}\\vspace{2mm}"))
    return div
  end
  if div.classes:includes("terminal-demo") then
    local name = div.attributes["example"]
    local step = div.attributes["step"]
    assert(name and name:match("^[a-z0-9-]+$"), "Invalid example")
    assert(not step or step:match("^[a-z0-9-]+$"), "Invalid checkpoint")
    local file = name == "allocation" and (assert(step, "Allocation file required") .. ".c") or
      ((step and step ~= "01-array") and ("checkpoints/" .. step .. ".c") or "main.c")
    local mode = div.attributes["mode"] or "run"
    assert(mode == "run" or mode == "valgrind", "Invalid terminal mode")
    local command = "make " .. mode .. (name == "allocation" and (" FILE=" .. file) or ((step and step ~= "01-array") and (" STEP=" .. step) or ""))
    if FORMAT:match("revealjs") then
      return pandoc.RawBlock("html", '<div class="terminal-example" data-example="' .. name .. '" data-file="' .. file .. '"><p><code>demos/' .. name .. '/' .. file .. '</code></p><p>Terminal: <code>' .. command .. '</code></p></div>')
    end
    return pandoc.Para({pandoc.Code("demos/" .. name .. "/" .. file), pandoc.LineBreak(), pandoc.Str("Terminal: "), pandoc.Code(command)})
  end
  if div.classes:includes("demo") then
    local name = div.attributes["example"]
    assert(name and name:match("^[a-z0-9-]+$"), "Invalid live example")
    local step = div.attributes["step"]
    assert(not step or step:match("^[a-z0-9-]+$"), "Invalid live step")
    if FORMAT:match("revealjs") then
      local attr = step and (' data-live-stage="' .. step .. '"') or ''
      return pandoc.RawBlock("html", '<button type="button" class="live-c-button" data-live-example="' .. name .. '"' .. attr .. '>Run live C ↗</button>')
    end
    local file = name == "allocation" and (assert(step, "Allocation file required") .. ".c") or
      ((step and step ~= "01-array") and ("checkpoints/" .. step .. ".c") or "main.c")
    return pandoc.RawBlock("latex", "{\\scriptsize Live example: \\texttt{demos/" .. name .. "/" .. file .. "}\\par}")
  end
  if div.classes:includes("block") then
    local title = div.attributes["title"] or ""
    if FORMAT:match("beamer") then
      local env = "block"
      if div.classes:includes("example") then env = "exampleblock" end
      if div.classes:includes("alert") then env = "alertblock" end
      div.content:insert(1, pandoc.RawBlock("latex", "\\begin{" .. env .. "}{" .. title .. "}"))
      div.content:insert(pandoc.RawBlock("latex", "\\end{" .. env .. "}"))
    elseif title ~= "" then
      div.content:insert(1, pandoc.Div({pandoc.Para({pandoc.Str(title)})}, pandoc.Attr("", {"block-title"})))
    end
    return div
  end
  if FORMAT:match("beamer") and div.classes:includes("small-note") then
    div.content:insert(1, pandoc.RawBlock("latex", "{\\small"))
    div.content:insert(pandoc.RawBlock("latex", "}"))
    return div
  end
end

-- Keep inline answer emphasis identical in Reveal and the printed handout.
function Span(span)
  if FORMAT:match("beamer") and span.classes:includes("marker") then
    local colour = "Green"
    if span.classes:includes("marker-plum") then colour = "Plum" end
    if span.classes:includes("marker-gold") then colour = "Gold" end
    if span.classes:includes("marker-red") then colour = "Red" end
    span.content:insert(1, pandoc.RawInline("latex", "\\CourseMarker{Marker" .. colour .. "Fill}{Marker" .. colour .. "Ink}{"))
    span.content:insert(pandoc.RawInline("latex", "}"))
    return span.content
  end
  if FORMAT:match("beamer") and
      (span.classes:includes("answer") or span.classes:includes("answer-choice")) then
    span.content:insert(1, pandoc.RawInline("latex", "{\\color{CourseGreen}\\bfseries "))
    span.content:insert(pandoc.RawInline("latex", "}"))
    return span.content
  end
end
