-- Include code from the compiled examples. One source for slides and demos.
function CodeBlock(block)
  local source = block.attributes["file"]
  if not source then return nil end
  local f = assert(io.open(source, "r"), "Cannot open " .. source)
  local text = f:read("*a")
  f:close()
  local region = block.attributes["region"]
  if region then
    local first = "// slide:" .. region .. ":begin\n"
    local last = "// slide:" .. region .. ":end"
    local a, b = text:find(first, 1, true)
    assert(a, "Missing region " .. region .. " in " .. source)
    local z = assert(text:find(last, b + 1, true))
    text = text:sub(b + 1, z - 1):gsub("\n%s*$", "")
    -- Regions are indented uniformly when inside a C function.
    local indent = text:match("^( +)")
    if indent then text = text:gsub("^" .. indent, ""):gsub("\n" .. indent, "\n") end
  end
  block.text = text:gsub("\n$", "")
  block.attributes["file"] = nil
  block.attributes["region"] = nil
  return block
end

function Image(image)
  if FORMAT:match("beamer") and image.src:match("%.svg$") then
    image.src = image.src:gsub("%.svg$", ".pdf")
    -- Every TikZ figure has the same 22 cm canvas and label size. Keep that
    -- common scale in print as well, rather than forcing equal image heights.
    image.attributes.width = "100%"
  end
  return image
end

-- Explicit column widths make LaTeX wrap table cells instead of overflowing.
function Table(tbl)
  if #tbl.colspecs == 2 then
    tbl.colspecs[1][2] = 0.36
    tbl.colspecs[2][2] = 0.64
  elseif #tbl.colspecs == 3 then
    tbl.colspecs[1][2] = 0.44
    tbl.colspecs[2][2] = 0.26
    tbl.colspecs[3][2] = 0.30
  end
  return tbl
end

function Div(div)
  if FORMAT:match("beamer") and div.classes:includes("lesson-flow") then
    return div:walk({ Header = function(header)
      if header.level ~= 3 then return nil end
      return pandoc.Div({
        pandoc.RawBlock("latex", "{\\color{CourseBlue}\\large\\bfseries"),
        pandoc.Para(header.content),
        pandoc.RawBlock("latex", "\\par}\\vspace{2mm}")
      })
    end })
  end
  if FORMAT:match("beamer") and div.classes:includes("step-result") then
    local colour = div.classes:includes("red") and "CourseRed" or "CourseGreen"
    div.content:insert(1, pandoc.RawBlock("latex", "\\vspace{2mm}{\\color{" .. colour .. "}\\large"))
    div.content:insert(pandoc.RawBlock("latex", "\\par}\\vspace{2mm}"))
    return div
  end
  if div.classes:includes("terminal-demo") then
    local name = div.attributes["example"]
    local step = div.attributes["step"]
    assert(name and name:match("^[a-z0-9-]+$"), "Invalid example")
    assert(not step or step:match("^[a-z0-9-]+$"), "Invalid checkpoint")
    local file = name == "allocation" and (assert(step, "Allocation file required") .. ".c") or
      ((step and step ~= "01-array") and ("checkpoints/" .. step .. ".c") or "main.c")
    local mode = div.attributes["mode"] or "run"
    assert(mode == "run" or mode == "valgrind", "Invalid terminal mode")
    local command = "make " .. mode .. (name == "allocation" and (" FILE=" .. file) or ((step and step ~= "01-array") and (" STEP=" .. step) or ""))
    if FORMAT:match("revealjs") then
      return pandoc.RawBlock("html", '<div class="terminal-example" data-example="' .. name .. '" data-file="' .. file .. '"><p><code>demos/' .. name .. '/' .. file .. '</code></p><p>Terminal: <code>' .. command .. '</code></p></div>')
    end
    return pandoc.Para({pandoc.Code("demos/" .. name .. "/" .. file), pandoc.LineBreak(), pandoc.Str("Terminal: "), pandoc.Code(command)})
  end
  if div.classes:includes("demo") then
    local name = div.attributes["example"]
    assert(name and name:match("^[a-z0-9-]+$"), "Invalid live example")
    local step = div.attributes["step"]
    assert(not step or step:match("^[a-z0-9-]+$"), "Invalid live step")
    if FORMAT:match("revealjs") then
      local attr = step and (' data-live-stage="' .. step .. '"') or ''
      return pandoc.RawBlock("html", '<button type="button" class="live-c-button" data-live-example="' .. name .. '"' .. attr .. '>Run live C ↗</button>')
    end
    local file = name == "allocation" and (assert(step, "Allocation file required") .. ".c") or
      ((step and step ~= "01-array") and ("checkpoints/" .. step .. ".c") or "main.c")
    return pandoc.RawBlock("latex", "{\\scriptsize Live example: \\texttt{demos/" .. name .. "/" .. file .. "}\\par}")
  end
  if div.classes:includes("block") then
    local title = div.attributes["title"] or ""
    if FORMAT:match("beamer") then
      local env = "block"
      if div.classes:includes("example") then env = "exampleblock" end
      if div.classes:includes("alert") then env = "alertblock" end
      div.content:insert(1, pandoc.RawBlock("latex", "\\begin{" .. env .. "}{" .. title .. "}"))
      div.content:insert(pandoc.RawBlock("latex", "\\end{" .. env .. "}"))
    elseif title ~= "" then
      div.content:insert(1, pandoc.Div({pandoc.Para({pandoc.Str(title)})}, pandoc.Attr("", {"block-title"})))
    end
    return div
  end
  if FORMAT:match("beamer") and div.classes:includes("small-note") then
    div.content:insert(1, pandoc.RawBlock("latex", "{\\small"))
    div.content:insert(pandoc.RawBlock("latex", "}"))
    return div
  end
end
