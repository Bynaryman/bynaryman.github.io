#include <stdio.h>
#include <stdlib.h>

// slide:struct:begin
typedef struct list_elem_t {
    int value;
    struct list_elem_t *next;
} list_elem_t;
// slide:struct:end

// slide:create:begin
list_elem_t *create_element(int value)
{
    list_elem_t *e = malloc(sizeof *e);
    if (e != NULL) {
        e->value = value;
        e->next = NULL;
    }
    return e;
}
// slide:create:end

/* l must point to a valid head pointer, possibly containing NULL. */
// slide:insert:begin
int insert_head(list_elem_t **l, int value)
{
    list_elem_t *e = create_element(value);
    if (e == NULL) return -1;
    e->next = *l;
    *l = e;
    return 0;
}
// slide:insert:end

// slide:walk:begin
void print_list(const list_elem_t *p)
{
    while (p != NULL) {
        printf("%d -> ", p->value);
        p = p->next;
    }
    puts("NULL");
}
// slide:walk:end

// slide:erase:begin
void erase_list(list_elem_t **l)
{
    while (*l != NULL) {
        list_elem_t *old = *l;
        *l = old->next;
        free(old);
    }
}
// slide:erase:end

#ifndef LISTES_NO_MAIN
int main(void)
{
    list_elem_t *head = NULL;
    if (insert_head(&head, 20) != 0 || insert_head(&head, 10) != 0) {
        erase_list(&head);
        return EXIT_FAILURE;
    }
    print_list(head);
    erase_list(&head);
    print_list(head);
    return EXIT_SUCCESS;
}
#endif
