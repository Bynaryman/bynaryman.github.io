#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    // slide:allocation:begin
    size_t n = 3;
    int *tab = malloc(n * sizeof *tab);
    if (tab == NULL) {
        return EXIT_FAILURE;
    }
    for (size_t i = 0; i < n; ++i) {
        tab[i] = 10 * (int)(i + 1);
    }
    // slide:allocation:end
    for (size_t i = 0; i < n; ++i) {
        printf("%d%s", tab[i], i + 1 == n ? "\n" : " ");
    }
    // slide:free:begin
    free(tab);
    tab = NULL;
    // slide:free:end
    return EXIT_SUCCESS;
}
