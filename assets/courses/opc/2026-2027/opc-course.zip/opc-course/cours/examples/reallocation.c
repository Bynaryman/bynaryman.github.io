#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *tab = malloc(3 * sizeof *tab);
    if (tab == NULL) return EXIT_FAILURE;
    for (size_t i = 0; i < 3; ++i) tab[i] = 10 * (int)(i + 1);
    size_t new_n = 5; /* Strictly positive, checked before multiplication. */
    if (new_n > SIZE_MAX / sizeof *tab) {
        free(tab);
        return EXIT_FAILURE;
    }
    // slide:realloc:begin
    int *tmp = realloc(tab, new_n * sizeof *tab);
    if (tmp == NULL) {
        free(tab);
        return EXIT_FAILURE;
    }
    tab = tmp;
    // slide:realloc:end
    for (size_t i = 3; i < new_n; ++i) tab[i] = 10 * (int)(i + 1);
    for (size_t i = 0; i < new_n; ++i) {
        printf("%d%s", tab[i], i + 1 == new_n ? "\n" : " ");
    }
    free(tab);
    return EXIT_SUCCESS;
}
