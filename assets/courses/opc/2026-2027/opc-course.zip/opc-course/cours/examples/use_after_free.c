/* Intentionally invalid: run only as an explicit sanitizer demonstration. */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *p = malloc(sizeof *p);
    if (p == NULL) return EXIT_FAILURE;
    *p = 42;
    int *alias = p;
    free(p);
    p = NULL;
    printf("%d\n", *alias); /* Undefined behaviour: use after free. */
    return EXIT_SUCCESS;
}
