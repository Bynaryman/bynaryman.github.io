# Source coverage

## Allocation and user-defined types: selected PowerPoint

Authoritative source, selected by the lecturer: **CM/CM-all-2025.pptx**, A. Kritikakou.
Absolute PowerPoint slides **281–312**, headed **CM10 Dynamic memory allocation**.
The previous CM7 PDF map is superseded for this lecture. The new English deck has
56 slides (including introduction and section dividers): some source pages are split, and memory failures motivate their repairs.
No required type, matrix representation or quiz group is removed.

The audit reads the actual slide text **and embedded code images** (especially
292 and 310), rather than treating slide count as evidence of coverage.
[allocation-coverage.json](allocation-coverage.json) records the source checksum
and stable target IDs. Tests check those references, not teaching completeness;
the content column below records the manual semantic review.

| PowerPoint slide | New slide IDs | Required content retained |
|--:|:--|:--|
| 281 | [title-slide](01-allocation.qmd#title-slide) | Allocation lecture title |
| 282 | [start-code](01-allocation.qmd#start-code), [memory-layout](01-allocation.qmd#memory-layout), [storage-duration](01-allocation.qmd#storage-duration) | Static/global, automatic/stack and dynamic/heap storage; contiguous block versus separate allocations; allocation time |
| 283 | [storage-duration](01-allocation.qmd#storage-duration) | Whole-program static lifetime; block/call automatic lifetime; implementation-managed storage |
| 284 | [runtime-size](01-allocation.qmd#runtime-size), [storage-duration](01-allocation.qmd#storage-duration), [local-lifetime](01-allocation.qmd#local-lifetime) | Runtime-dependent sizes, lifetime control and stack exhaustion from recursion |
| 285 | [runtime-size](01-allocation.qmd#runtime-size), [malloc](01-allocation.qmd#malloc), [initialise](01-allocation.qmd#initialise), [free](01-allocation.qmd#free), [leak](01-allocation.qmd#leak), [dangling](01-allocation.qmd#dangling), [dangling-explained](01-allocation.qmd#dangling-explained) | Allocation during execution; programmer controls exact size and lifetime; leaks and dangling pointers |
| 286 | [leak](01-allocation.qmd#leak) | Unreferenced allocated memory; memory cells and lost pointer diagram |
| 287 | [ownership](01-allocation.qmd#ownership) | Growing memory use under repeated leaks; explicit C release versus Java garbage collection |
| 288 | [dangling](01-allocation.qmd#dangling), [local-lifetime](01-allocation.qmd#local-lifetime), [dangling-explained](01-allocation.qmd#dangling-explained) | Pointer outlives object: heap deallocation and automatic-object lifetime |
| 289 | [allocation-api](01-allocation.qmd#allocation-api) | stdlib.h; malloc, calloc, realloc and free |
| 290 | [malloc](01-allocation.qmd#malloc), [allocation-size](01-allocation.qmd#allocation-size) | malloc prototype; byte count; size_t range/type; uninitialised storage; sizeof; void pointer; corrected C cast rule |
| 291 | [free](01-allocation.qmd#free), [dangling](01-allocation.qmd#dangling), [free-contract](01-allocation.qmd#free-contract), [dangling-explained](01-allocation.qmd#dangling-explained) | free prototype/no return value; allocation start/NULL arguments; invalid/double-free undefined behaviour; programmer responsibility |
| 292 | [runtime-size](01-allocation.qmd#runtime-size), [initialise](01-allocation.qmd#initialise), [free](01-allocation.qmd#free) | Complete original 100-integer allocation, NULL check, failure path, zero-initialisation loop, free |
| 293 | [quiz-allocation](01-allocation.qmd#quiz-allocation) | Inherited quiz questions 1–5 |
| 294 | [array](01-allocation.qmd#array) | Generic element count times sizeof; four integers; contiguous elements, address arithmetic, bounds |
| 295 | [string](01-allocation.qmd#string) | Character allocation; byte layout; string terminator |
| 296 | [string-assignment](01-allocation.qmd#string-assignment), [string-trace](01-allocation.qmd#string-trace), [string-copy](01-allocation.qmd#string-copy) | All three assignments s="hello", p=s, s="bye"; three pointer states; leaked allocation identified |
| 297 | [matrix-flat](01-allocation.qmd#matrix-flat) | Rows times columns allocation; 4×3 flat matrix layout and indexing |
| 298 | [matrix-rows](01-allocation.qmd#matrix-rows) | Automatic array of row pointers; each row separately allocated; pointer and row storage |
| 299 | [matrix-dynamic](01-allocation.qmd#matrix-dynamic) | Allocated pointer table and separately allocated rows; two levels of indirection |
| 300 | [quiz-arrays](01-allocation.qmd#quiz-arrays) | Inherited quiz questions 6–8 |
| 301 | [user-types](01-allocation.qmd#user-types) | User-defined types: enum, struct, typedef |
| 302 | [enum](01-allocation.qmd#enum) | Enum syntax/tag, named integer constants, default 0–6, variable definition and assignment |
| 303 | [struct-type](01-allocation.qmd#struct-type) | Structure syntax/tag and members of varied types; type alone creates no object |
| 304 | [struct-objects](01-allocation.qmd#struct-objects), [struct-type](01-allocation.qmd#struct-type) | Object definitions allocate storage; type/member declarations are not object initialisers |
| 305 | [struct-init](01-allocation.qmd#struct-init) | Separate and combined structure/object definitions; Paul Bert/12 aggregate initialisation; allocated size |
| 306 | [alignment](01-allocation.qmd#alignment) | Alignment, word/hardware motivation, padding; corrected implementation-dependent explanation |
| 307 | [padding-code](01-allocation.qmd#padding-code), [padding-layout](01-allocation.qmd#padding-layout) | Both grouped/interleaved structure definitions, field order, byte diagram, 16/20-byte examples |
| 308 | [member-dot](01-allocation.qmd#member-dot), [member-arrow](01-allocation.qmd#member-arrow) | Structure and pointer member access, integer assignment and strcpy in both forms |
| 309 | [typedef](01-allocation.qmd#typedef) | Typedef syntax, integer alias, anonymous enum BOOLEAN, struct date alias |
| 310 | [nested-types](01-allocation.qmd#nested-types) | Both source code images: short day/month, int year, weekday enum and nested structure typedef |
| 311 | [nested-access](01-allocation.qmd#nested-access) | 3/9/2014 initializer, object nested access, pointer binding and nested pointer access |
| 312 | [quiz-types](01-allocation.qmd#quiz-types) | Inherited quiz questions 9–12 |

## Teaching additions and explicit corrections

- Files 01–04 in `demos/allocation/` develop an independent string copy:
  shared storage, a short allocation missing the terminator byte, the corrected
  size with a remaining leak, then free. The slides explain observed results
  after each Vim/GCC/Valgrind run. TikZ diagrams show the shared and separate
  character storage and the extra byte. This is a use of malloc, not a claim
  that an automatic array cannot make a copy.
- File 05 applies the same operations to integers and retains the original
  100-integer example. Files 06–09 introduce independent memory errors into it.
  Heap/stack and lifetime explanations follow the working string copy.
- Files 10–18 retain the required arrays, strings, matrix representations and
  user-defined types. The later pointer-assignment example remains because
  all three assignments on source slide 296 are part of the inherited content.

- New opposing-direction stack/heap TikZ schematic. It is a typical process
  model, not a C requirement; real allocators may use separate mappings.
- Short native runs precede error terminology. The Valgrind workflow also
  develops the tool already introduced on PowerPoint slide 145. Out-of-bounds
  and uninitialised-value experiments explain the existing bounds and malloc
  rules; they do not replace required course content.
- Slide 290: `sizeof` is an operator, and a malloc cast is unnecessary in C.
  Allocation failure is checked. The source's minimum size_t range is retained.
- Slide 296: retain all assignments and alias states, explicitly identify the
  leaked heap block, then show an actual character copy as the repair.
- Slides 298–299: full executable versions check allocation failures and release
  earlier rows on partial failure. Slide sketches focus on the representation.
- Slides 306–307: sizes/alignment depend on the implementation; the hardware
  word-size explanation is qualified. Both structure declarations are restored.
- Slide 309: correct the source typo LENGHT to LENGTH.
- Slides 310–311: English names preserve the original member types and nesting;
  the last assignment changes 2014 to 2026 to make the pointer update observable.
- Original quiz asset is unchanged. Its older CM7/CM8 labels do not match the
  CM10 heading of the selected PowerPoint; all three question groups remain.

The [90-minute runbook](../docs/allocation-runbook.md) gives actual live edits,
commands and repairs, without per-slide time limits. A slide is a visual step, not an additional activity.
