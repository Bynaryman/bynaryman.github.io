# Source coverage

## Allocation and user-defined types: selected PowerPoint

Authoritative source, selected by the lecturer: **CM/CM-all-2025.pptx**, A. Kritikakou.
Absolute PowerPoint slides **281–312**, headed **CM10 Dynamic memory allocation**.
The previous CM7 PDF map is superseded for this lecture. The new English deck has
52 slides (including introduction and section dividers): some source pages are split, and memory failures motivate their repairs.
Types, matrix representations and quiz groups are retained. The separate
three-assignment string example from source slide 296 is optional at the lecturer’s request.

The audit reads the actual slide text **and embedded code images** (especially
292 and 310), rather than treating slide count as evidence of coverage.
[allocation-coverage.json](allocation-coverage.json) records the source checksum
and stable target IDs. Tests check those references, not teaching completeness;
the content column below records the manual semantic review.

| PowerPoint slide | New slide IDs | Required content retained |
|--:|:--|:--|
| 281 | [title-slide](01-allocation.qmd#title-slide) | Allocation lecture title |
| 282 | [start-code](01-allocation.qmd#start-code), [memory-layout](01-allocation.qmd#memory-layout), [storage-duration](01-allocation.qmd#storage-duration) | Static/global, automatic/stack and dynamic/heap storage; contiguous block versus separate allocations; allocation time |
| 283 | [storage-duration](01-allocation.qmd#storage-duration) | Whole-program static lifetime; block/call automatic lifetime; implementation-managed storage |
| 284 | [runtime-size](01-allocation.qmd#runtime-size), [storage-duration](01-allocation.qmd#storage-duration), [local-lifetime](01-allocation.qmd#local-lifetime) | Runtime-dependent sizes, lifetime control and stack exhaustion from recursion |
| 285 | [runtime-size](01-allocation.qmd#runtime-size), [malloc](01-allocation.qmd#malloc), [initialise](01-allocation.qmd#initialise), [free](01-allocation.qmd#free), [leak](01-allocation.qmd#leak), [dangling](01-allocation.qmd#dangling), [dangling-explained](01-allocation.qmd#dangling-explained) | Allocation during execution; programmer controls exact size and lifetime; leaks and dangling pointers |
| 286 | [leak](01-allocation.qmd#leak) | Unreferenced allocated memory; memory cells and lost pointer diagram |
| 287 | [ownership](01-allocation.qmd#ownership) | Growing memory use under repeated leaks; explicit C release versus Java garbage collection |
| 288 | [dangling](01-allocation.qmd#dangling), [local-lifetime](01-allocation.qmd#local-lifetime), [dangling-explained](01-allocation.qmd#dangling-explained) | Pointer outlives object: heap deallocation and automatic-object lifetime |
| 289 | [allocation-api](01-allocation.qmd#allocation-api) | stdlib.h; malloc, calloc, realloc and free |
| 290 | [malloc](01-allocation.qmd#malloc), [allocation-size](01-allocation.qmd#allocation-size) | malloc prototype; byte count; size_t range/type; uninitialised storage; sizeof; void pointer; corrected C cast rule |
| 291 | [free](01-allocation.qmd#free), [dangling](01-allocation.qmd#dangling), [free-contract](01-allocation.qmd#free-contract), [dangling-explained](01-allocation.qmd#dangling-explained) | free prototype/no return value; allocation start/NULL arguments; invalid/double-free undefined behaviour; programmer responsibility |
| 292 | [runtime-size](01-allocation.qmd#runtime-size), [initialise](01-allocation.qmd#initialise), [free](01-allocation.qmd#free) | Complete original 100-integer allocation, NULL check, failure path, zero-initialisation loop, free |
| 293 | [quiz-allocation](01-allocation.qmd#quiz-allocation) | Inherited quiz questions 1–5 |
| 294 | [array](01-allocation.qmd#array) | Generic element count times sizeof; four integers; contiguous elements, address arithmetic, bounds |
| 295 | [copy-shared](01-allocation.qmd#copy-shared), [copy-terminator](01-allocation.qmd#copy-terminator), [copy-independent](01-allocation.qmd#copy-independent) | Character allocation; byte layout; string terminator |
| 296 | [copy-shared](01-allocation.qmd#copy-shared), [copy-characters](01-allocation.qmd#copy-characters), [leak](01-allocation.qmd#leak) | Assignment versus copying and lost allocations remain covered. The separate hello/bye trace is omitted from the lecture at the lecturer’s request; retained in demos/allocation/12-string-assignment.c as an optional reference. |
| 297 | [matrix-flat](01-allocation.qmd#matrix-flat) | Rows times columns allocation; 4×3 flat matrix layout and indexing |
| 298 | [matrix-rows](01-allocation.qmd#matrix-rows) | Automatic array of row pointers; each row separately allocated; pointer and row storage |
| 299 | [matrix-dynamic](01-allocation.qmd#matrix-dynamic) | Allocated pointer table and separately allocated rows; two levels of indirection |
| 300 | [quiz-arrays](01-allocation.qmd#quiz-arrays) | Inherited quiz questions 6–8 |
| 301 | [user-types](01-allocation.qmd#user-types) | User-defined types: enum, struct, typedef |
| 302 | [enum](01-allocation.qmd#enum) | Enum syntax/tag, named integer constants, default 0–6, variable definition and assignment |
| 303 | [struct-type](01-allocation.qmd#struct-type) | Structure syntax/tag and members of varied types; type alone creates no object |
| 304 | [struct-objects](01-allocation.qmd#struct-objects), [struct-type](01-allocation.qmd#struct-type) | Object definitions allocate storage; type/member declarations are not object initialisers |
| 305 | [struct-init](01-allocation.qmd#struct-init) | Separate and combined structure/object definitions; Paul Bert/12 aggregate initialisation; allocated size |
| 306 | [alignment](01-allocation.qmd#alignment) | Alignment, word/hardware motivation, padding; corrected implementation-dependent explanation |
| 307 | [padding-code](01-allocation.qmd#padding-code), [padding-layout](01-allocation.qmd#padding-layout) | Both grouped/interleaved structure definitions, field order, byte diagram, 16/20-byte examples |
| 308 | [member-dot](01-allocation.qmd#member-dot), [member-arrow](01-allocation.qmd#member-arrow) | Structure and pointer member access, integer assignment and strcpy in both forms |
| 309 | [typedef](01-allocation.qmd#typedef) | Typedef syntax, integer alias, anonymous enum BOOLEAN, struct date alias |
| 310 | [nested-types](01-allocation.qmd#nested-types) | Both source code images: short day/month, int year, weekday enum and nested structure typedef |
| 311 | [nested-access](01-allocation.qmd#nested-access) | 3/9/2014 initializer, object nested access, pointer binding and nested pointer access |
| 312 | [quiz-types](01-allocation.qmd#quiz-types) | Inherited quiz questions 9–12 |

## Teaching additions and explicit corrections

- Files 01–04 in `demos/allocation/` develop an independent string copy:
  shared storage, a short allocation missing the terminator byte, the corrected
  size with a remaining leak, then free. The slides explain observed results
  after each Vim/GCC/Valgrind run. TikZ diagrams show the shared and separate
  character storage and the extra byte. This is a use of malloc, not a claim
  that an automatic array cannot make a copy.
- File 05 applies the same operations to integers and retains the original
  100-integer example. Files 06–09 introduce independent memory errors into it.
  Heap/stack and lifetime explanations follow the working string copy.
- Files 10–18 retain the required arrays, strings, matrix representations and
  user-defined types. The structure lesson builds `live-types.c` incrementally
  from `types-start.c`; completed file 16 is a recovery reference. Dot and arrow
  access precede the padding investigation. Source slide 296’s separate
  pointer-assignment trace is now an optional reference.

- New opposing-direction stack/heap TikZ schematic. It is a typical process
  model, not a C requirement; real allocators may use separate mappings.
- Short native runs precede error terminology. The Valgrind workflow also
  develops the tool already introduced on PowerPoint slide 145. Out-of-bounds
  and uninitialised-value experiments explain the existing bounds and malloc
  rules; they do not replace required course content.
- Slide 290: `sizeof` is an operator, and a malloc cast is unnecessary in C.
  Allocation failure is checked. The source's minimum size_t range is retained.
- Slide 296: the lecturer requested removal of the separate assignment example
  from the slide sequence. Keep its C file as an optional reference. Assignment,
  character copying and lost allocations are still explained by the opening
  and memory-error examples. The grid section proceeds directly from a row
  to the three matrix representations.
- Slides 298–299: full executable versions check allocation failures and release
  earlier rows on partial failure. Slide sketches focus on the representation.
- Slides 306–307: sizes/alignment depend on the implementation; the hardware
  word-size explanation is qualified. Both structure declarations are restored.
- Slide 309: correct the source typo LENGHT to LENGTH.
- Slides 310–311: English names preserve the original member types and nesting;
  the last assignment changes 2014 to 2026 to make the pointer update observable.
- Original quiz asset is unchanged. Its older CM7/CM8 labels do not match the
  CM10 heading of the selected PowerPoint; all three question groups remain.

The [90-minute runbook](../docs/allocation-runbook.md) gives actual live edits,
commands and repairs, without per-slide time limits. A slide is a visual step, not an additional activity.

## Linked lists: continuation of structures and allocation

Authoritative source: **CM/CM-all-2025.pptx**, slides **313–355**.
The 84-slide lecture retains every linked-list topic. Eight
section dividers connect the teaching steps; they introduce no additional topic.
Repeated failure explanations and assignment previews share a slide with the
corresponding code step; the source mapping records these merges.
The copied-pointer failure precedes the pointer-to-pointer repair. Function calls
now show entry, allocation, return-value transfer and completed call separately.
Source slides 325 and 326 each have their own state. Hash tables (356 onward)
are excluded.
The original title also mentioned hash tables; this deck's title reflects its
linked-list-only scope.

[linked-lists-coverage.json](linked-lists-coverage.json) records the source
checksum and every source-to-target mapping. The TikZ call traces name each function, show the values stored in pointer
variables and keep their positions fixed between steps. One C run illustrates
one operation, followed by its explanation; the old combined demonstration and
browser live-code buttons are removed from this lecture.

| PowerPoint slide | New slide IDs |
|---:|---|
| 313 | [title-slide](02-linked-lists.qmd#title-slide) |
| 314 | [chain](02-linked-lists.qmd#chain) |
| 315 | [why-lists](02-linked-lists.qmd#why-lists) |
| 316 | [node-type](02-linked-lists.qmd#node-type) |
| 317 | [empty](02-linked-lists.qmd#empty) |
| 318 | [create](02-linked-lists.qmd#create), [create-call](02-linked-lists.qmd#create-call), [create-allocated](02-linked-lists.qmd#create-allocated), [create-initialised](02-linked-lists.qmd#create-initialised) |
| 319 | [return-node](02-linked-lists.qmd#return-node), [return-lifetime](02-linked-lists.qmd#return-lifetime) |
| 320 | [first-node](02-linked-lists.qmd#first-node) |
| 321 | [head-address](02-linked-lists.qmd#head-address), [head-preserve](02-linked-lists.qmd#head-preserve) |
| 322 | [head-update](02-linked-lists.qmd#head-update) |
| 323 | [head-return](02-linked-lists.qmd#head-return) |
| 324 | [head-copy](02-linked-lists.qmd#head-copy), [head-argument](02-linked-lists.qmd#head-argument) |
| 325 | [head-node](02-linked-lists.qmd#head-node) |
| 326 | [head-local](02-linked-lists.qmd#head-local) |
| 327 | [head-leak](02-linked-lists.qmd#head-leak) |
| 328 | [insert-head-start](02-linked-lists.qmd#insert-head-start) |
| 329 | [keep-head](02-linked-lists.qmd#keep-head) |
| 330 | [head-wrong](02-linked-lists.qmd#head-wrong) |
| 331 | [head-wrong](02-linked-lists.qmd#head-wrong) |
| 332 | [head-reset](02-linked-lists.qmd#head-reset) |
| 333 | [head-link](02-linked-lists.qmd#head-link) |
| 334 | [head-publish](02-linked-lists.qmd#head-publish) |
| 335 | [insert-middle-start](02-linked-lists.qmd#insert-middle-start) |
| 336 | [keep-successor](02-linked-lists.qmd#keep-successor) |
| 337 | [middle-wrong](02-linked-lists.qmd#middle-wrong) |
| 338 | [middle-wrong](02-linked-lists.qmd#middle-wrong) |
| 339 | [middle-reset](02-linked-lists.qmd#middle-reset) |
| 340 | [middle-link](02-linked-lists.qmd#middle-link) |
| 341 | [middle-link](02-linked-lists.qmd#middle-link) |
| 342 | [middle-publish](02-linked-lists.qmd#middle-publish) |
| 343 | [insert-tail-start](02-linked-lists.qmd#insert-tail-start) |
| 344 | [tail-link](02-linked-lists.qmd#tail-link) |
| 345 | [tail-publish](02-linked-lists.qmd#tail-publish) |
| 346 | [tail-complete](02-linked-lists.qmd#tail-complete) |
| 347 | [tail-complete](02-linked-lists.qmd#tail-complete) |
| 348 | [delete-head-start](02-linked-lists.qmd#delete-head-start) |
| 349 | [delete-head-free](02-linked-lists.qmd#delete-head-free) |
| 350 | [delete-head-free](02-linked-lists.qmd#delete-head-free) |
| 351 | [delete-middle-start](02-linked-lists.qmd#delete-middle-start) |
| 352 | [delete-middle-free](02-linked-lists.qmd#delete-middle-free) |
| 353 | [delete-tail-start](02-linked-lists.qmd#delete-tail-start) |
| 354 | [delete-tail-free](02-linked-lists.qmd#delete-tail-free) |
| 355 | [doubly-linked](02-linked-lists.qmd#doubly-linked), [list-costs](02-linked-lists.qmd#list-costs) |

The live code checks malloc failures and cleans partial lists. The short deletion
traces assume the shown nodes exist; the guide also explains empty and singleton
cases. C arguments are always passed by value: passing &head allows writing to
head through its address. Nodes need not be contiguous, rather than necessarily
being noncontiguous. Finding a position still costs traversal; link changes alone
are constant time once the position is known. A fixed array has fixed capacity,
not an absolute prohibition on resizing dynamically allocated storage.

The original tail trace connects the old tail before showing the new NULL link.
Both the new diagrams and executable examples initialise next to NULL before
publishing the new node; the later visual step checks that end-of-list invariant.
The overview demonstrates playlist insertion and removal before C. Three
intro programs, introduced by the Linked-list basics section, build A, link B
and traverse the two-node list in main before
extracting a helper. Song IDs A-E are integer character constants displayed
with %c, consistently across the examples. Arrow endpoints use node anchors;
node, previous, tail and victim are shown when an operation uses them. Byte counts and concrete
addresses in the inherited call diagrams are illustrative, not ABI guarantees.

See [the linked-list teacher runbook](../docs/linked-lists-runbook.md).

### Opening review and motivation

The 84-slide lecture retains the 313–355 mapping above. Added slides review
all ten questions in `CM/Untitled document-1.pdf`, recap `struct` and `typedef`,
and introduce a playlist whose order changes. Section dividers separate all
Kahoot corrections, the struct/typedef reminder, and the linked-list lecture.
The reminders follow q10, rather than interrupting the corrections.
Section 7 introduces doubly linked lists through the playlist’s Previous button,
connecting the preceding search for a predecessor to the extra prev link.
Each quiz question restores its
original snippet and answer choices in two columns (three choices for q7/q8,
four for the others). One reveal highlights the intended answer and shows the
explanation. The struct-copy question has a second slide explaining the caller.
Original code defects are retained, including q2's missing stdlib.h, q6's VLA
and q9's void main(); their consequences are discussed rather than silently
corrected. Only whitespace and the source ellipses are reformatted. These
additions are recorded separately in `linked-lists-coverage.json`.

Pedagogical reference: [CS50 linked-list notes](https://cs50.harvard.edu/x/notes/5/#linked-lists),
for the progression from a drawn chain to its C representation. The required
content remains the PowerPoint above; drawings and programs here are original.

The final cost table makes slide 355’s qualitative comparison explicit.
Both representations use Theta(n) node storage; doubly linked nodes add one
pointer each. Section 8 contains four newly written review questions with
answer reveals. No linked-list Kahoot questions or game link appear in source
slides 313–355; the next Kahoot break in CM-all-2025.pptx is slide 391.
