# Allocation CM · teaching notes

Source: CM/CM-all-2025.pptx, slides 281–312. User-defined types are included in
that source; lists and hash tables begin afterward. The whole class is 90 minutes.

## One file order

Use [demos/allocation/README.md](../demos/allocation/README.md): **01 → 17**.
All commands run in `demos/allocation`. Open the named file in Vim; Make takes
that exact filename, for example `make valgrind FILE=07-dangling.c`.
There is no second sequence of checkpoints or standalone folders to follow.

## 01–04 · Build a working allocation

1. **01-fixed-array.c**: locate the four-element declaration. What changes if the user needs 100?
2. **02-capacity.c**: enter 4, then 100. Reading a count does not enlarge the array.
3. **03-missing-free.c**: inspect malloc and its NULL check. Enter 100: normal output looks correct. Run Valgrind and locate the unreleased allocation.
4. **04-free.c**: compare the added free after printf. Run Valgrind: the leak is gone. Locate the local pointer and allocated block in the stack/heap diagram.

Runtime size alone does not require malloc; some C implementations support
variable-length automatic arrays. Here heap storage makes allocation-failure
handling and lifetime explicit. Counts are bounded to 1–1000.

## 05–08 · Break one thing, then repair it

Each file starts from **04-free.c**, not the previous faulty version. Enter 4.
Ask for a prediction, run Valgrind, read the diagnostic, then reveal the slide's
explanation. Edit the fault in Vim and rerun the same command.

| File | Observation | Repair |
| --- | --- | --- |
| 05-uninitialised.c | printf uses values that were never written. A displayed zero is not proof of initialisation. | Restore the whole loop before printf. |
| 06-overrun.c | Invalid write at p[4], after the four valid elements. | Use i < count. |
| 07-dangling.c | Invalid reads after free; it can still print zeros and have no leak. | Move free after the last read. |
| 08-leak.c | free(NULL) does nothing; the original block is definitely lost. | Keep its address until free, then clear the pointer if useful. |

On the read-after-free slide, reveal the invalid read first, then name the dangling
pointer. The next slide defines the term and shows the corrected order. A dangling
pointer is a state; the invalid read is an operation using it. Free does not set
p to NULL. Clearing p does not repair other dangling aliases.

Use the storage-duration and API slides as a recap, then quiz questions 1–5.
The commands use GCC with -g -O0 and Valgrind with leak checking and origin tracking.
Zero errors concern the tested execution. ASan/UBSan are developer checks only.

## 09–14 · Arrays, strings and matrices

- **09-array.c**: locate the addresses of successive elements.
- **10-string.c**: find the terminator and count the required bytes.
- **11-string-assignment.c**: trace s = "hello", p = s, s = "bye". Assignment changes pointers, not characters. Copy into the allocation and free it to repair the leak.
- **12-matrix-flat.c**, **13-matrix-rows.c**, **14-matrix-dynamic.c**: compare prepared code. Count allocations, locate the pointer table and rows, and identify which releases are needed.

Preserve quiz questions 6–8. Matrix variants are comparisons, not three new live
coding sequences. Full C files check allocation failures and clean up partial rows.

## 15–17 · User-defined types

- **15-types.c**: predict enum values and changes to structure members. Run before explaining dot and arrow notation.
- **16-padding.c**: compare the two definitions and predict their sizes. Run before explaining alignment and the padding diagram.
- **17-nested.c**: follow object and pointer access to nested date members.

Preserve quiz questions 9–12. Adjust live typing and discussion to the room;
there are no per-slide timing targets.

## Dependencies and this machine

Install GCC, Make and Valgrind through the operating system's package manager.
Some distributions also require matching libc debug symbols. `scripts/valgrind.sh`
uses system Valgrind first, with an optional local tool under `build/tools/`.
Normal builds do not download software or debug information.

For this workspace, Valgrind 3.27.1 was built from the official release under
`build/tools/valgrind-new/usr`. Matching loader debug information for the installed
libc was retrieved from Arch's debuginfod service into `build/tools/debug/`.
The wrapper supplies that path, so the checked examples run without root access
or network access during class. These binaries/debug files are local prerequisites,
not versioned course assets. On another machine, install that machine's packages.
If libc is upgraded, recheck the native demos and refresh matching debug symbols.

## References for the lecturer

The demonstration rhythm is inspired by [CS50 Lecture 4](https://cs50.harvard.edu/x/2025/notes/4/):
predict, run, inspect, repair. The syllabus and inherited examples remain OPC's.
The C snippets and TikZ drawings here are authored for this course, not copied
from CS50 slides. See the [Valgrind quick start](https://valgrind.org/docs/manual/quick-start.html)
for compiling with debug information and interpreting reports, and the
[official release page](https://valgrind.org/downloads/current.html) for tool sources.
