# Allocation CM · 90-minute teaching runbook

Source: `CM/CM-all-2025.pptx`, slides 281–312 (CM10), including user-defined
types. The deck is English. The [coverage map](../cours/SOURCE-MAP.md) records
the retained material and corrections. The 41 visual steps fit the following
**planned** timing; rehearsal is still needed for the actual audience.

## Before class

```sh
make check
make present
```

Open `http://127.0.0.1:8877/01-allocation.html`. Use a second terminal with a large
font if you prefer Vim. Each folder has `main.c` and a Makefile. `make valgrind`
compiles with debug information and runs Memcheck, returning 99 for a diagnosed
memory error. A nonzero status in the deliberately broken examples is expected.

In the slides, **Run live C → Run with: Valgrind → Compile & run** executes the
current editor text with local GCC and real Valgrind. Ctrl+Enter runs again;
Escape returns to the slides. Broken examples select Valgrind automatically.
Source files stay unchanged by browser edits. Reload file discards that draft
and picks up disk edits. Standard input for example 15 starts with `4`.

The visible command is printed above the real output. Source line numbers refer
to the code in the editor (region-marker comments are removed there); the same
terminal file can have slightly different line numbers. PIDs and addresses vary.

## Timing

| Minutes | Visual steps | Lecturer action |
|--:|:--|:--|
| 0–8 | Small program → memory layout → storage lifetime | Run 14 once; predict the effect of two calls. Point to static data, descending stack and ascending heap. |
| 8–22 | Runtime size → malloc → initialise → free → API | Enter 4 then 100 in 15. Build the original 100-integer example in 01. Distinguish count, bytes, pointer and object. |
| 22–39 | Clean run → bounds → initialisation → leak → dangling → ownership | One continuous debugging sequence, with predictions and short edits; use the table below. |
| 39–43 | Questions 1–5 | Original quiz, with discussion. |
| 43–51 | Array → string → assignment trace → copy | Predict hello/bye, then trace all three pointer states. Connect the lost allocation to the earlier leak. |
| 51–60 | Three matrix representations | Explain each drawing and count allocations/releases. Use code as reference; do not live-code all three matrices. |
| 60–63 | Questions 6–8 | Original quiz. |
| 63–76 | enum → struct → initialisation → layout | Show both grouped/interleaved definitions before measuring padding with 09. |
| 76–85 | dot/arrow → typedef → nested types | Keep both strcpy access forms. Predict the nested update, then run 10 if time permits. |
| 85–90 | Questions 9–12 | Original quiz and final questions. |

The additional slides separate code, memory states and explanation. They are
not extra exercises. Protect all three quiz breaks and the user-defined types
section. If a discussion runs long, shorten a repeated execution (for example,
the second repaired uninitialised-value run), not required source content.

## One debugging sequence

Start with 04 and establish the working baseline. Then break **one rule at a
time**. Do not combine all faults into one program.

| Folder | Predict / inspect | Minimal live repair |
|:--|:--|:--|
| `04-array` | Four elements; all are initialised; free after use. Compile, run normally, then with Valgrind. | Clean baseline; find zero errors and all blocks freed. |
| `16-overrun` | `i <= 4` reaches index 4. Find **Invalid write**, the source line and the block boundary. | Change `<=` to `<`; rerun. |
| `17-uninitialised` | malloc does not initialise integers. Follow the **uninitialised value** report to the allocation. | Add `a[0] = 10;` before printf; rerun. |
| `18-lost-allocation` | `p = NULL` discards the only address. Find **definitely lost** and the allocation call site. | Add `free(p);` before `p = NULL;`; rerun. |
| `02-dangling` | Object freed before read. Follow **Invalid read → free → malloc**. | Move printf before free; rerun. |

The small helper function in 18 lets the allocation pointer leave its stack
frame before process exit, giving a reliable lost-block demonstration instead
of depending on stale pointer bits in registers. It is not a second concept to
teach. The pointer assignment is the actual bug.

Terminal workflow, using the overrun example:

```sh
cd demos/16-overrun
vim main.c
make run
make valgrind
# Edit <= to < in Vim, save, and run make valgrind again.
```

Equivalent commands with a system Valgrind installation:

```sh
gcc -std=c17 -Wall -Wextra -Wpedantic -O0 -g main.c -o program
./program
valgrind --leak-check=full --track-origins=yes ./program
```

The lecture UI offers GCC alone or Valgrind. ASan/UBSan are extra developer
checks used by `make check`; they are not part of this class. Unlike Memcheck,
ASan does not track ordinary uninitialised scalar values. The runner rejects
combining sanitizers with Valgrind. Zero reported errors only
concerns the executed path; it is not proof that every input is safe.

## Strings and layout

03 preserves the source assignments exactly. The first overwrite loses the
allocation, `p = s` copies an address, and the last assignment changes only `s`.
For a live repair, replace the body with the slide's `malloc(6)` / `strcpy` /
`printf` / `free` pattern, add `<string.h>`, and rerun. Do not free a literal.

09 prints the actual sizes and ratio offsets. Use them to explain the 16/20-byte
illustration; do not present those sizes as universal. Examples 07 and 08 include
partial-allocation cleanup even though the slide sketches omit those branches.

## Dependencies and this machine

Install GCC, Make and Valgrind through the operating system's package manager.
Some distributions also require matching libc debug symbols. `scripts/valgrind.sh`
uses system Valgrind first, with an optional local tool under `build/tools/`.
Normal builds do not download software or debug information.

For this workspace, Valgrind 3.27.1 was built from the official release under
`build/tools/valgrind-new/usr`. Matching loader debug information for the installed
libc was retrieved from Arch's debuginfod service into `build/tools/debug/`.
The wrapper supplies that path, so the checked examples run without root access
or network access during class. These binaries/debug files are local prerequisites,
not versioned course assets. On another machine, install that machine's packages.
If libc is upgraded, recheck the native demos and refresh matching debug symbols.

## References for the lecturer

The demonstration rhythm is inspired by [CS50 Lecture 4](https://cs50.harvard.edu/x/2025/notes/4/):
predict, run, inspect, repair. The syllabus and inherited examples remain OPC's.
The C snippets and TikZ drawings here are authored for this course, not copied
from CS50 slides. See the [Valgrind quick start](https://valgrind.org/docs/manual/quick-start.html)
for compiling with debug information and interpreting reports, and the
[official release page](https://valgrind.org/downloads/current.html) for tool sources.
