# Dynamic allocation: teaching notes

Required content: `CM/CM-all-2025.pptx`, slides **281–312**. Linked lists
and hash tables begin afterward. The whole class is 90 minutes.

## Before class

All commands run in `demos/allocation`. Prepare working copies once:

```sh
cp -n 01-copy-alias.c live-copy.c
cp -n 05-integers.c live-integers.c
cp -n types-start.c live-types.c
```

`-n` preserves existing files: inspect them if you have rehearsed. Keep Vim and a
second terminal open in this folder. Save with `:w` before compiling.

The numbered files **01 → 18** are references, not eighteen mandatory runs.
Edit `live-copy.c` for the opening, `live-integers.c` for memory errors, and
`live-types.c` for structures. If an edit goes wrong, use the stated numbered
reference to restore the working file. Files 10, 13–15, 17 and 18 are prepared
comparisons run at the points below. Files 11 and 12 are optional references outside the slide sequence; file 16
is the completed type reference, not the program to run at the section opening.

Start each investigation with a question. Leave the answer hidden, inspect or
edit C, collect predictions, then run. Return to Reveal to explain the actual
result. A repair is another small edit followed by a check. Recap slides need no
new run. Right reveals the next step; after the last reveal it changes slide.
The student PDF shows all explanations; present the Reveal version in class.

## Recover the exact step

Each coding slide in the printed guide gives a `cp` command that restores the
state shown on that slide. Use recovery **instead of** repeating its normal edits;
some checkpoints deliberately contain the error being investigated. Separate
repair commands are included where the repair happens on the same slide.
All commands run in `demos/allocation`. For example, the read-after-free step:

```sh
cp 08-dangling.c live-integers.c
printf '4\n' | make valgrind FILE=live-integers.c
```

From Vim, use `:!cp 08-dangling.c live-integers.c`, then `:e!` to reload the
copied file. This discards unsaved edits. Do not save the old buffer over the
checkpoint. Run with `:!printf '4\n' | make valgrind FILE=live-integers.c`.
For ordinary live edits, save with `:w` before running.

The report says `Invalid read of size 4`, then describes an address inside a block
that was `free'd`, with the release and allocation call sites. It may still print
zeros. `All heap blocks were freed` describes leaks only; check `ERROR SUMMARY`
for invalid accesses. On the checked four-integer example there are two errors.

Intermediate string/type states are in `recovery/`. They are rescue copies, not
an extra lesson sequence. Quizzes and slides with no C edit explicitly need no
new run. When recovering a prepared comparison, use the working-file command in
the recovery block; the normal instruction may name the saved reference instead.

## Speaking notes and printed guide

`docs/allocation-teacher-cues.json` defines the actions, expected results and
reveals for every slide. `python3 scripts/teacher_cues.py` puts the same cues into
Quarto speaker notes. `make slides` and `make pdf` do this before rendering.
The printable guide builder also synchronises notes and derives current slide
numbers. Edit the JSON for teaching instructions; edit QMD for student content.

## 01–04 · Make an independent string copy

The task is to keep `original` equal to `hello` while changing `copy` to `Hello`.
Stay in `main`; leave scope and lifetime explanations until after the working copy.
No input is needed. The programs use standard C, with no CS50 library.

1. **01-copy-alias.c**: slides 6–8 contain one experiment and one run.
   Slide 6 states the goal; do not run. On slide 7, read the code and collect
   predictions for both lines before running `make run FILE=live-copy.c`
   (working copy prepared from 01-copy-alias.c). Return and reveal the output.
   Both say `Hello`. Slide 8 explains this result; do not run again.
   `char *copy = original` copied the address. This is a logical mistake, not an
   invalid memory access: Valgrind correctly reports no error. Trace the shared
   storage on the diagram. `original` is a writable array, not a string literal.
2. **02-copy-short.c**: replace the pointer assignment with
   `malloc(strlen(original))` and check for NULL. Add `strcpy(copy, original)`
   before the edit. Run `make run FILE=live-copy.c` after predictions, then use
   `make valgrind FILE=live-copy.c` on the next slide. It may print the desired
   output despite an invalid write. Locate that write at `strcpy`: five bytes
   were allocated but six were copied, including the terminator. There can also
   be invalid reads and a leak. Fix the first invalid access before investigating
   the rest; do not pretend this report contains only one issue.
3. **03-copy-leak.c**: add **only `+ 1`** to the allocation. Rerun Valgrind.
   Invalid accesses disappear; **6 bytes definitely lost** remains.
   Keep the same report for the next slide; do not run a second time there. Connect the
   report to our allocation. We have not yet released the copy.
4. **04-copy-free.c**: add **only `free(copy)`**, after the final printf.
   Verify `hello` / `Hello`, zero errors and all blocks freed. Do not free
   `original`, and do not read `copy` after free. The independent-storage diagram
   shows the moment before free.

Let students predict before each run. Reveal the slide's diagnostic only after
reading the real terminal output, and reveal the repair after students propose it.
If someone spots the missing byte early, acknowledge it and test that prediction.
There is no promised crash: the short copy has undefined behaviour.

A second character array can also make an independent copy. This example teaches
how to request separate storage with malloc, not that malloc is the only solution.
VLAs are outside this course's scope; -Werror=vla enforces that teaching choice,
not a claim that C forbids runtime-sized automatic arrays.

## 05 · Apply the same operations to integers

**live-integers.c**, prepared from **05-integers.c**, is a new, correct program.
The slide How much space for integers? shows only the task. Ask for the byte count while Vim is still hidden;
then open the integer program to inspect and run it. Enter 100. The next slide explains
the allocation formula after the run. Locate the size
calculation, NULL check, zero-initialisation loop, use and free. Compare one byte
per character with sizeof(int) bytes per integer. Counts are bounded to 1–1000.
Run Valgrind once to establish the clean baseline before making the next faults.
The source course's fixed-100 version remains in demos/reference/01-malloc/main.c.

## 06–09 · Break one thing, then repair it

Make each fault in **live-integers.c**, starting from the repaired version.
References 06–09 each start from **05-integers.c**, not the previous fault. Enter 4.
Ask for a prediction, run Valgrind, read the diagnostic, then reveal the slide's
explanation. Edit the fault in Vim and rerun `make valgrind FILE=live-integers.c`.

| File | Observation | Repair |
| --- | --- | --- |
| 06-uninitialised.c | printf uses values that were never written. A displayed zero is not proof of initialisation. | Restore the whole loop before printf. |
| 07-overrun.c | Invalid write at p[4], after the four valid elements. | Use i < count. |
| 08-dangling.c | Invalid reads after free; it can still print zeros and have no leak. | Move free after the last read. |
| 09-leak.c | free(NULL) does nothing; the original block is definitely lost. | Keep its address until free, then clear the pointer if useful. |

On the read-after-free slide, reveal the invalid read first, then name the dangling
pointer. The next slide defines the term and shows the corrected order. A dangling
pointer is a state; the invalid read is an operation using it. Free does not set
p to NULL. Clearing p does not repair other dangling aliases.

After repairing 08, pause the terminal work for the helper-function example:
"If we return a local array's address, does that keep the array alive?" Trace the
call and return in three reveals. No invalid dereference needs to be run. Leaving
the block ends an ordinary local's lifetime, just as free ended the heap block's
lifetime. The message is that an address does not keep its target alive.

Compare the three storage lifetimes, then return to the repaired integer program
for 09: "If changing the pointer does not release the block, what happens when we
erase its only address?" A dangling pointer concerns an object whose lifetime
ended; a leak leaves an allocation alive but unreachable. Repair and verify 09.

Ask who reclaims a lost block in C before contrasting garbage collection. Recap
the operations already used (malloc, writing zeros, free), introduce calloc and
realloc as related library functions, then collect the valid arguments to free.
Finish with quiz questions 1–5.
The commands use GCC with -g -O0 and Valgrind with leak checking and origin tracking.
Zero errors concern the tested execution. ASan/UBSan are developer checks only.

## 10, 13–15 · One row, then a grid

We have already allocated an integer row. This section adds rows and columns;
there is no second string lesson.

- **10-array.c**: recall contiguous elements. Predict address spacing, run, then reveal the indexing rule.
- **13-matrix-flat.c**: extend the row to twelve integers for a 4-by-3 grid. Ask for the index of row 2, column 1, then its value after `10*i+j`. Inspect, run, and reveal index 7/value 21 and the diagram.
- **14-matrix-rows.c**: store each row separately. Predict the grid and which objects need free. Inspect, run, then reveal the automatic table and allocated rows.
- **15-matrix-dynamic.c**: allocate the row-pointer table too. Count blocks and propose release order before running. Reveal the allocated table and rows afterward.

All three matrices print the same grid; the comparisons concern storage and
cleanup. These are prepared comparisons, not three typing exercises. Full files
check allocation failures and clean up partial rows. Preserve quiz questions 6–8.
Files 11 and 12 remain optional string references, outside the lecture sequence.

## 16–18 · Build an object before measuring its layout

Do not run completed **16-types.c** at the start: it would expose all later
results. Build **live-types.c** from the small **types-start.c** instead:

1. Add `enum day` before main, then `today`, its assignment and its printf inside main. Predict, run, then explain the enum values.
2. Add `struct address` before main. Explain the difference between defining a type and creating objects; no run is needed yet.
3. Add one initialised `home` and its printf inside main. Predict, run, then explain initialisation. The alternative declaration on the slide is not extra code to add.
4. Insert dot assignments immediately before the home printf. Predict and run: `14 Rue de Paris`. Reveal the dot explanation.
5. Insert the pointer and arrow assignments after the dot assignments, before that same printf. Predict and run: `16 Rue de Paris`. Reveal the alias and operator explanation. Do not rerun merely to repeat the result.

Use `make run FILE=live-types.c` after saving each executable step. The printed
guide gives the exact additions. `16-types.c` is the completed recovery reference.

Now ask how much storage a structure occupies. On the slide showing both member
orders, predict sizes and run **17-padding.c** once. The next two slides explain
alignment and locate padding in the measured layout; they have no run command.

Introduce typedef, then the nested date type, without running code yet. On the
nested-access slide, read the updates and predict the final year. Run
**18-nested.c** once, then reveal that both paths reach the same object.

Preserve quiz questions 9–12. No linked-list or hash-table content follows.
There are no per-slide timing targets.

## Dependencies and this machine

Install GCC, Make and Valgrind through the operating system's package manager.
Some distributions also require matching libc debug symbols. `scripts/valgrind.sh`
uses system Valgrind first, with an optional local tool under `build/tools/`.
Normal builds do not download software or debug information.

For this workspace, Valgrind 3.27.1 was built from the official release under
`build/tools/valgrind-new/usr`. Matching loader debug information for the installed
libc was retrieved from Arch's debuginfod service into `build/tools/debug/`.
The wrapper supplies that path, so the checked examples run without root access
or network access during class. These binaries/debug files are local prerequisites,
not versioned course assets. On another machine, install that machine's packages.
If libc is upgraded, recheck the native demos and refresh matching debug symbols.

## References for the lecturer

The string-copy introduction and demonstration rhythm are inspired by [CS50 Lecture 4](https://cs50.harvard.edu/x/2025/notes/4/):
predict, run, inspect, repair. The syllabus and inherited examples remain OPC's.
The C snippets and TikZ drawings here are authored for this course, not copied
from CS50 slides. See the [Valgrind quick start](https://valgrind.org/docs/manual/quick-start.html)
for compiling with debug information and interpreting reports, and the
[official release page](https://valgrind.org/downloads/current.html) for tool sources.
