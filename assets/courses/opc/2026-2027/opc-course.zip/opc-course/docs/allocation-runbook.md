# Allocation CM · teaching notes

Source: `CM/CM-all-2025.pptx`, slides 281–312. Slides 301–312 are the
original user-defined-types section; slide 313 begins lists and hash tables.
See [coverage](../cours/SOURCE-MAP.md). The class is 90 minutes; section dividers
are navigation cues, not a minute-by-minute schedule.

## Setup

Open `cours/_output/01-allocation.html` in Firefox. Keep Vim and a terminal beside it.

```sh
cd demos/00-allocation
vim main.c
make run
```

Start with the question on the slide, then work in the C file. Ask students to
predict the result before running. Read the actual compiler/Valgrind output.
Only then return to the explanation or repair slide. Keep editing `main.c`;
the checkpoint files are complete fallback versions, not mandatory file switches.
Run each command from the corresponding example folder.

## 1. Allocate an array

Ask: the program has space for four integers; what changes if we need 100?
Open `main.c` and identify `int p[4]`. Add the input and capacity check from
`02-capacity.c`. Try 4, then 100; reading a count did not enlarge the array.

Replace the array declaration with `malloc(count * sizeof(int))` and check
`NULL`. Keep the existing initialization loop and output. **Do not add free yet.**
`03-missing-free.c` is this version. Enter 100: it prints correctly. Explain the
byte count from this expression, then ask whether correct output is enough.

Runtime size alone does not require malloc: some C implementations support
variable-length automatic arrays. Here allocation failure and lifetime are
explicit. The count is bounded to 1–1000; unrestricted input needs additional
size-overflow handling. Counts and indices use int/%d and parenthesized sizeof.

## 2. Find and fix memory errors

### Correct output, unreleased memory

```sh
make run STEP=03-missing-free
make valgrind STEP=03-missing-free
# Enter 100 in each run.
```

Read `definitely lost`, the allocation location, and the heap summary. The program
printed correctly but did not release the block. Add `free(p)` **after** printf
in Vim and rerun Valgrind. Read zero errors and all heap blocks freed. The saved
repair is `03-heap.c`. Now explain free's contract and show the stack/heap diagram.
Do not promise a crash from a leak: the missing release is the defect.

### Allocated does not mean initialized

From the repaired version, remove the initialization loop. Ask what printf will
read; run normally and under Valgrind with input 4. `05-uninitialised.c` saves this
single change. Read the uninitialised-value report and trace its origin to malloc.
A printed zero does not prove initialization.

Restore the complete loop and rerun. Both first and last elements are read, so
initializing only p[0] is insufficient. The initialization slide now explains
this repair. Change the assigned value to 7, predict the output and run; undo it.

### Bounds and lifetime

Start each experiment from clean `03-heap.c`, not the previous faulty version.

| Question | Edit / saved file | Observe, then repair |
|:--|:--|:--|
| Which iteration is outside the block? | `< count` → `<= count`; `04-overrun.c` | Invalid write; restore `<`. |
| Can we read after releasing it? | Move free before printf; `07-dangling.c` | Invalid read; release after the last read. |
| Can we release a block after losing its address? | Put p = NULL before free; `06-leak.c` | Definitely lost; preserve the address until free, then clear the pointer if useful. |

Run `make valgrind STEP=04-overrun` (or the matching file stem) and enter 4.
A diagnostic and a nonzero make exit are expected for faulty examples. Read the
source location, repair in Vim and rerun before naming the rule on the slide.
Then use the lifetime, ownership and API slides to collect what the experiments
established. Preserve quiz questions 1–5.

The Makefile uses GCC with `-g -O0`; `-g` gives Valgrind source locations.
`make valgrind` enables leak checking and origin tracking. Zero reported errors
concern this run, not every possible input. ASan/UBSan are developer checks and
are not part of the lecture.

## 3. Arrays, strings and matrices

Run 04-array and locate element addresses. Run 05-string and find the terminator.
In 03-leak, predict the three pointer assignments before running. Use the pointer
diagram to explain the observed aliases; repair using malloc/strcpy/free from the
slide. Do not free a string literal.

Compare prepared files 06, 07 and 08. Ask where each row lives, how many allocations
were made, and what must be released. Run them, then use the three matrix diagrams.
Do not live-type every matrix. Preserve quiz questions 6–8.

## 4. User-defined types

This is a separate topic already present in the original CM. Open 19-types:
predict the enum values and object/member changes, run it, then name enum/struct
and dot/arrow access. Run 09 to measure actual sizes and member offsets; use the
padding diagram afterward. These small measurements are explicitly converted to
int for %d. Run 10 for nested member access. Preserve quiz questions 9–12.

Choose the amount of live typing and discussion based on the room. The checkpoint
files allow resuming quickly; they are not extra exercises to cover in addition
to the slides. There are no per-slide or per-section timing targets.

## Dependencies and this machine

Install GCC, Make and Valgrind through the operating system's package manager.
Some distributions also require matching libc debug symbols. `scripts/valgrind.sh`
uses system Valgrind first, with an optional local tool under `build/tools/`.
Normal builds do not download software or debug information.

For this workspace, Valgrind 3.27.1 was built from the official release under
`build/tools/valgrind-new/usr`. Matching loader debug information for the installed
libc was retrieved from Arch's debuginfod service into `build/tools/debug/`.
The wrapper supplies that path, so the checked examples run without root access
or network access during class. These binaries/debug files are local prerequisites,
not versioned course assets. On another machine, install that machine's packages.
If libc is upgraded, recheck the native demos and refresh matching debug symbols.

## References for the lecturer

The demonstration rhythm is inspired by [CS50 Lecture 4](https://cs50.harvard.edu/x/2025/notes/4/):
predict, run, inspect, repair. The syllabus and inherited examples remain OPC's.
The C snippets and TikZ drawings here are authored for this course, not copied
from CS50 slides. See the [Valgrind quick start](https://valgrind.org/docs/manual/quick-start.html)
for compiling with debug information and interpreting reports, and the
[official release page](https://valgrind.org/downloads/current.html) for tool sources.
