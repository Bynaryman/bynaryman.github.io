# Allocation CM · 90-minute teaching runbook

Source: `CM/CM-all-2025.pptx`, slides 281–312 (CM10), including user-defined
types. The deck is English. The [coverage map](../cours/SOURCE-MAP.md) records
the retained material and corrections. The 47 slides fit the following
**planned** timing; rehearsal is still needed for the actual audience.

## Start with C

Open [demos/00-allocation/main.c](../demos/00-allocation/main.c). Keep one editor
open while the program changes. Show the slides after a run, to explain a
memory state or name a rule.

```sh
cd demos/00-allocation
vim main.c
make run
```

The [saved steps](../demos/00-allocation/README.md) are complete programs. Use
`make run STEP=03-heap` to run a checkpoint without replacing your working file.
The program waits for a count on standard input. Use 100 for the allocation
example and 4 for the memory-error investigations.

Open `cours/_output/01-allocation.html` in Firefox. No server is needed. The
slide's terminal command runs from its example folder. Open saved checkpoints
with `vim checkpoints/03-heap.c`, then use `make run STEP=03-heap`.

## Section cues

- **0–3:** professional introduction and route through the lecture.
- **3–23:** allocate, use, release.
- **23–43:** find and repair memory errors; quiz 1–5.
- **43–63:** arrays, strings and matrices; quiz 6–8.
- **63–90:** user-defined types; quiz 9–12.

The four divider slides are real Reveal sections and also appear in the PDF.

## Timing

| Minutes | Code to run or edit first | Slides to use afterward |
|--:|:--|:--|
| 0–3 | Introduce yourself and show the section plan. | Whoami and roadmap. |
| 3–7 | In 00, run the four-element array. Add the input/count check. Try 4, then 100. | Fixed capacity and the rejected request. |
| 7–14 | Replace the array with malloc, check NULL, keep the loop/output, add free. Run with 100, then change the initial value and rerun. | The original 100-integer example, initialization and release. |
| 14–23 | Inspect count, sizeof(int), the local pointer, and its allocated block in the same program. | Byte count, heap/stack diagram, storage lifetimes and the four-function API. Example 14 is optional support for globals/locals. |
| 23–39 | Run clean step 3 with Valgrind. Make one change at a time as described below. | Bounds, initialization, lost address, dangling pointer, local lifetime and ownership. |
| 39–43 | Questions 1–5. | Original quiz and discussion. |
| 43–51 | Run 04, then 05 and 03. Predict the string assignments before executing; repair the copy. | Array layout, terminator and the three alias states. |
| 51–60 | Compare and run 06, 07 and 08. Identify allocation, indexing and cleanup in each file. | Three matrix diagrams; count their allocations and releases. |
| 60–63 | Questions 6–8. | Original quiz. |
| 63–71 | Open 19-types. Predict the weekday and initial address; run the program. | enum, struct, object definition and initialization. |
| 71–76 | Run 09 to measure both structure sizes and offsets. | Alignment and padding diagram. |
| 76–85 | In 19, edit member access through home and p. Then predict and run 10. | Dot/arrow equivalence, typedef and nested members. |
| 85–90 | Questions 9–12. | Original quiz and final questions. |

Do not live-type every matrix or type definition: compare the prepared C files
and make a small edit. Preserve all three quiz breaks and the types section.
The pacing remains a plan requiring rehearsal.

## One program, one fault at a time

`checkpoints/03-heap.c` is the working version. Run it normally, then under
Valgrind. Read zero reported errors and all blocks freed before changing it.
Restore this clean version before each new fault. The saved steps are fallbacks,
not a requirement to jump between files while explaining.

| Step | Change from the clean program | Observe, then repair |
|:--|:--|:--|
| 4 | Change `i < count` to `i <= count`. | Invalid write at index count. Restore `<`. |
| 5 | Remove the initialization loop. | Uninitialized values used by printf. Restore the whole loop; it reads both the first and last elements. |
| 6 | Insert `p = NULL` immediately before `free(p)`. | Definitely lost allocation; free(NULL) releases nothing. Move the assignment after free. |
| 7 | Move `free(p)` before printf. | Invalid read after free. Move the release after the last read. |

For each change: ask for a prediction, run Valgrind, read the diagnostic and
source location, then show the diagram or explanation. Repair the code and run
it again. Keep the loop, input and output familiar throughout.

```sh
make valgrind STEP=04-overrun
# Enter 4. A diagnostic and nonzero exit are expected.
```

The underlying commands are:

```sh
gcc -std=c17 -Wall -Wextra -Wpedantic -O0 -g main.c -o program
./program
valgrind --leak-check=full --track-origins=yes ./program
```

`-g` supplies source locations; `-O0` keeps the debug build simple. The wrapper
also uses `--error-exitcode=99` so detected errors give a nonzero status.
Compiler and Valgrind messages refer to the actual `.c` file open in Vim.
Counts and indices use `int` with `%d`; allocation sizes use `sizeof(type)`.
The size measurements in example 09 explicitly convert these small values to
`int` for printing. The API slide retains `size_t`, as in the source course;
introducing its `%zu` format is unnecessary for these examples.

The loop starts with zeros. Do not rely on a zero printed by an uninitialized
read: the C value is indeterminate even if the current storage happens to
contain zero bits. Zero Valgrind errors describe the executed path, not all
possible inputs. ASan/UBSan remain developer checks, outside the lecture.

## Strings and layout

03 preserves the source assignments exactly. The first overwrite loses the
allocation, `p = s` copies an address, and the last assignment changes only `s`.
For a live repair, replace the body with the slide's `malloc(6)` / `strcpy` /
`printf` / `free` pattern, add `<string.h>`, and rerun. Do not free a literal.

09 prints the actual sizes and ratio offsets. Use them to explain the 16/20-byte
illustration; do not present those sizes as universal. Examples 07 and 08 include
partial-allocation cleanup even though the slide sketches omit those branches.

## Dependencies and this machine

Install GCC, Make and Valgrind through the operating system's package manager.
Some distributions also require matching libc debug symbols. `scripts/valgrind.sh`
uses system Valgrind first, with an optional local tool under `build/tools/`.
Normal builds do not download software or debug information.

For this workspace, Valgrind 3.27.1 was built from the official release under
`build/tools/valgrind-new/usr`. Matching loader debug information for the installed
libc was retrieved from Arch's debuginfod service into `build/tools/debug/`.
The wrapper supplies that path, so the checked examples run without root access
or network access during class. These binaries/debug files are local prerequisites,
not versioned course assets. On another machine, install that machine's packages.
If libc is upgraded, recheck the native demos and refresh matching debug symbols.

## References for the lecturer

The demonstration rhythm is inspired by [CS50 Lecture 4](https://cs50.harvard.edu/x/2025/notes/4/):
predict, run, inspect, repair. The syllabus and inherited examples remain OPC's.
The C snippets and TikZ drawings here are authored for this course, not copied
from CS50 slides. See the [Valgrind quick start](https://valgrind.org/docs/manual/quick-start.html)
for compiling with debug information and interpreting reports, and the
[official release page](https://valgrind.org/downloads/current.html) for tool sources.
