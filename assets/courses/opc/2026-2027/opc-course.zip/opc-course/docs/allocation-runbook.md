# Dynamic allocation: teaching notes

Required content: `CM/CM-all-2025.pptx`, slides **281–312**. Linked lists
and hash tables begin afterward. The whole class is 90 minutes.

## One file order

Use [demos/allocation/README.md](../demos/allocation/README.md): **01 → 18**.
All commands run in `demos/allocation`. Open the named file in Vim; Make takes
that exact filename. Each file is complete. Your own `scatchpad.c` is optional:
use `make run FILE=scatchpad.c` and `make valgrind FILE=scatchpad.c` as you edit.

## 01–04 · Make an independent string copy

The task is to keep `original` equal to `hello` while changing `copy` to `Hello`.
Stay in `main`; leave scope and lifetime explanations until after the working copy.
No input is needed. The programs use standard C, with no CS50 library.

1. **01-copy-alias.c**: ask for both outputs, then run. Both say `Hello`.
   `char *copy = original` copied the address. This is a logical mistake, not an
   invalid memory access: Valgrind correctly reports no error. Trace the shared
   storage on the diagram. `original` is a writable array, not a string literal.
2. **02-copy-short.c**: replace the pointer assignment with
   `malloc(strlen(original))` and check for NULL. Add `strcpy(copy, original)`
   before the edit. Run normally, then with Valgrind. It may print the desired
   output despite an invalid write. Locate that write at `strcpy`: five bytes
   were allocated but six were copied, including the terminator. There can also
   be invalid reads and a leak. Fix the first invalid access before investigating
   the rest; do not pretend this report contains only one issue.
3. **03-copy-leak.c**: add **only `+ 1`** to the allocation. Rerun Valgrind.
   Invalid accesses disappear; **6 bytes definitely lost** remains. Connect the
   report to our allocation. We have not yet released the copy.
4. **04-copy-free.c**: add **only `free(copy)`**, after the final printf.
   Verify `hello` / `Hello`, zero errors and all blocks freed. Do not free
   `original`, and do not read `copy` after free. The independent-storage diagram
   shows the moment before free.

Let students predict before each run. Reveal the slide's diagnostic only after
reading the real terminal output, and reveal the repair after students propose it.
If someone spots the missing byte early, acknowledge it and test that prediction.
There is no promised crash: the short copy has undefined behaviour.

A second character array can also make an independent copy. This example teaches
how to request separate storage with malloc, not that malloc is the only solution.
VLAs are outside this course's scope; -Werror=vla enforces that teaching choice,
not a claim that C forbids runtime-sized automatic arrays.

## 05 · Apply the same operations to integers

**05-integers.c** is a new, correct program. Enter 100, then 4. Locate the size
calculation, NULL check, zero-initialisation loop, use and free. Compare one byte
per character with sizeof(int) bytes per integer. Counts are bounded to 1–1000.
Run Valgrind once to establish the clean baseline before making the next faults.
The source course's fixed-100 version remains in demos/reference/01-malloc/main.c.

## 06–09 · Break one thing, then repair it

Each file starts from **05-integers.c**, not the previous faulty version. Enter 4.
Ask for a prediction, run Valgrind, read the diagnostic, then reveal the slide's
explanation. Edit the fault in Vim and rerun the same command.

| File | Observation | Repair |
| --- | --- | --- |
| 06-uninitialised.c | printf uses values that were never written. A displayed zero is not proof of initialisation. | Restore the whole loop before printf. |
| 07-overrun.c | Invalid write at p[4], after the four valid elements. | Use i < count. |
| 08-dangling.c | Invalid reads after free; it can still print zeros and have no leak. | Move free after the last read. |
| 09-leak.c | free(NULL) does nothing; the original block is definitely lost. | Keep its address until free, then clear the pointer if useful. |

On the read-after-free slide, reveal the invalid read first, then name the dangling
pointer. The next slide defines the term and shows the corrected order. A dangling
pointer is a state; the invalid read is an operation using it. Free does not set
p to NULL. Clearing p does not repair other dangling aliases.

Use the storage-duration and API slides as a recap, then quiz questions 1–5.
The commands use GCC with -g -O0 and Valgrind with leak checking and origin tracking.
Zero errors concern the tested execution. ASan/UBSan are developer checks only.

## 10–15 · Arrays, strings and matrices

- **10-array.c**: locate the addresses of successive elements.
- **11-string.c**: find the terminator and count the required bytes.
- **12-string-assignment.c**: trace s = "hello", p = s, s = "bye". Assignment changes pointers, not characters. Copy into the allocation and free it to repair the leak.
- **13-matrix-flat.c**, **14-matrix-rows.c**, **15-matrix-dynamic.c**: compare prepared code. Count allocations, locate the pointer table and rows, and identify which releases are needed.

Preserve quiz questions 6–8. Matrix variants are comparisons, not three new live
coding sequences. Full C files check allocation failures and clean up partial rows.

## 16–18 · User-defined types

- **16-types.c**: predict enum values and changes to structure members. Run before explaining dot and arrow notation.
- **17-padding.c**: compare the two definitions and predict their sizes. Run before explaining alignment and the padding diagram.
- **18-nested.c**: follow object and pointer access to nested date members.

Preserve quiz questions 9–12. Adjust live typing and discussion to the room;
there are no per-slide timing targets.

## Dependencies and this machine

Install GCC, Make and Valgrind through the operating system's package manager.
Some distributions also require matching libc debug symbols. `scripts/valgrind.sh`
uses system Valgrind first, with an optional local tool under `build/tools/`.
Normal builds do not download software or debug information.

For this workspace, Valgrind 3.27.1 was built from the official release under
`build/tools/valgrind-new/usr`. Matching loader debug information for the installed
libc was retrieved from Arch's debuginfod service into `build/tools/debug/`.
The wrapper supplies that path, so the checked examples run without root access
or network access during class. These binaries/debug files are local prerequisites,
not versioned course assets. On another machine, install that machine's packages.
If libc is upgraded, recheck the native demos and refresh matching debug symbols.

## References for the lecturer

The string-copy introduction and demonstration rhythm are inspired by [CS50 Lecture 4](https://cs50.harvard.edu/x/2025/notes/4/):
predict, run, inspect, repair. The syllabus and inherited examples remain OPC's.
The C snippets and TikZ drawings here are authored for this course, not copied
from CS50 slides. See the [Valgrind quick start](https://valgrind.org/docs/manual/quick-start.html)
for compiling with debug information and interpreting reports, and the
[official release page](https://valgrind.org/downloads/current.html) for tool sources.
