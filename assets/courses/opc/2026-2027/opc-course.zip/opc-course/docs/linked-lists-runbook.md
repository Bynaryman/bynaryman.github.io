# Linked lists: teacher preparation

Source: `CM/CM-all-2025.pptx`, slides **313–355**. The lecture continues structures
and dynamic allocation. Hash tables start at 356 and are not included.

The printable guide is `output/pdf/linked-lists-teacher-guide.pdf`. Every slide
has a purpose, speaking/action cue, expected observation, reveal cue, and a
recovery command when there is a C state. Use slide titles as well as numbers.

## Before class

```sh
firefox cours/_output/02-linked-lists.html
cd demos/linked-lists
cp -n 00-empty.c live-list.c
vim live-list.c
```

Run from this directory. In Vim, save with `:w`, then use `:!make run` or
`:!make valgrind`. No example needs stdin. After copying a recovery reference,
use `:e!` to reload rather than saving the old buffer over the new file.
Quarto's Reveal version hides explanations until Right; the student PDF shows
the completed explanations. No browser editor or live-code server is required. Slide changes are instant: motion
and automatic element animation are disabled, while answer fragments still
reveal on Right. Reload an already-open browser tab after rebuilding.

## Review before the linked-list lecture

Three section dividers mark the opening:

1. **Kahoot corrections:** all ten questions, including the q2 and q9 follow-ups.
2. **Struct reminder:** type versus object, then typedef.
3. **1. A playlist that changes:** operate on the drawn list before C.

The corrections use the ten screenshots from `CM/Untitled document-1.pdf`.
Each question shows the original snippet on the left and the original choices
on the right. Q7 and q8 have three choices; the others have four. Ask for a
letter and a reason. One Right turns the intended answer green and reveals
the full explanation; there are no pauses between its bullets.
Review titles use Kahoot (alloc) q1-q10, matching the screenshot order. Distinguish guaranteed effects
from assumptions: free(NULL) does nothing, while a leak requires losing all
usable references to an unreleased allocation. The added saved-reference example
shows q retaining the address and freeing it. The separate reminder returns
to the struct initialisation issue after all ten corrections. Q9 shows the whole program,
then revisits the caller on a separate explanation slide. The original missing
`stdlib.h`, VLA and `void main()` are retained and discussed in the teacher guide.
No terminal run is required for the review.

The playlist uses the summer-school pen highlight: plum for current song B,
amber for new song E, and green for the unchanged nodes. The same colours and
lower-half stroke are retained in the printable slides.

The playlist provides the motivation: insert E after the current song B, then
remove a song while preserving the rest. Refer back to those actions during
middle insertion/deletion. Known-position edits avoid moving later elements;
search and indexed access still require traversal. Arrays remain useful for
direct indexing and locality.

## The story

1. **Operate on a playlist first.** B is playing; insert E next. Compare the
   array shift with the two link changes. Draw E to C before redirecting B to E.
   Cancel E by reconnecting B to C. Trace the resulting playback order aloud.
   These slides use no C. Existing nodes keep their addresses; only links change.
2. **Build that representation in main.** Define the node, start with head NULL,
   then use `intro/01-one-node.c`, `intro/02-two-nodes.c`, and `intro/03-walk.c`.
   Build A, allocate B and link A to B, then walk with p. Each question precedes
   a terminal run; reveal the matching diagram afterwards. Character constants
   A-E are integer song IDs, printed with %c; no audio data or strings are involved.
3. **Extract repeated work.** Only now introduce create_element: allocating and
   initialising B repeated the same work as A. Reference 01 isolates one call,
   so the return-address trace has a purpose. Reference 02 links its result.
4. **Let the helper change head.** Predict 03 before running: changing l leaves
   caller head NULL and leaks a node. Rewind the failed call visually. At “Pass
   the address of head”, complete all four repair edits in Vim, predict and run
   04, then trace how *l writes main's pointer. C still copies the argument value.
5. **Implement the playlist edits.** Each operation resets to ABCD and separate
   E. Reference 06 overwrites head too soon and loses ABCD; 09 overwrites B.next
   and loses CD. Observe Valgrind, reset, then preserve the old link before
   redirecting it. Each broken example has one result slide; read its Valgrind
   report there, then reset. The drawings show NULL where the C code initialises next.
6. **Unlink and free.** Save the victim, reconnect the chain, then release the
   victim at the head, middle and tail. The tail needs its predecessor.
7. **Doubly linked lists.** The player needs a Previous button. Ask how to
   reach the preceding song from the current node, then introduce prev.
   Connect it to the predecessor search used for deletion, and explain the
   extra storage and link maintenance from the original comparison.

This follows the visual-model-before-C progression in
[CS50's linked-list explanation](https://cs50.harvard.edu/x/notes/5/#linked-lists).
The required topics and worked cases still come from CM-all-2025.pptx.

## Exact run points

In the stack/heap sequence, each Right advances to the next pictured state.
The code above the diagram names the statement just executed; the highlighted
bullet names its effect. Stack frames and heap objects stay in fixed positions.
`0x1000` and `0x7000` are illustrative addresses. `waiting` marks a caller's
pending initialisation, not a pointer value. Traces assume allocation succeeds.

The printed guide identifies the slide for each run. Do not run an operation
at its first setup diagram: first collect predictions and finish its edits.

| Reference | Observation |
|---|---|
| 00-empty.c | empty: 1 |
| intro/01-one-node.c | A -> NULL |
| intro/02-two-nodes.c | A -> B -> NULL |
| intro/03-walk.c | A -> B -> NULL; head unchanged |
| 01-create.c | head empty: 1, node value: A |
| 02-first-node.c | head -> A -> NULL |
| 03-head-copy.c | caller head empty: 1; one leaked node |
| 04-head-address.c | head -> A -> NULL; no leak |
| 06-head-lost.c | E only; ABCD leaked |
| 07-head-fixed.c | EABCD; no leak |
| 09-middle-lost.c | ABE; CD leaked |
| 10-middle-fixed.c | ABECD; no leak |
| 12-tail-fixed.c | ABCDE; no leak |
| 14-delete-head.c | BCD; no leak |
| 15-delete-middle.c | ACD; no leak |
| 16-delete-tail.c | ABC; no leak |

Setup files 05, 08, 11 and 13 are edit starting points, not extra demonstrations.
The operation files include list-support.h. Inspect its helpers once: they build
ABCD, traverse for printing, and clean up the remaining reachable nodes. Each
operation starts from its own pictured chain, so deletion of B means B, not the
new E from a previous example. The final cleanup happens after the illustrated
state; it must not be mistaken for the deletion being taught.

Operation diagrams match the runnable examples: a newly created node has
next = NULL. Only the malloc-before-initialisation trace uses question marks. Wrong-order examples lose nodes but do not deliberately invoke invalid
reads. Valgrind's nonzero exit is expected for those leaks.

A recovery file can include a completed operation whose statements are spread
across several visual steps. The guide says to wait until the run point and skip
edits already present. Numbered files and live-list.c are alternatives, not two
parallel lesson sequences.

## Rebuild

```sh
python3 scripts/linked_list_guide.py --notes-only
quarto render cours/02-linked-lists.qmd --to revealjs
quarto render cours/02-linked-lists.qmd --to beamer
python3 scripts/linked_list_guide.py
python3 scripts/check_linked_lists.py
```

Building the guide requires ReportLab. Student PDF rendering requires LuaLaTeX.
The guide and speaker notes use `docs/linked-lists-teacher-cues.json` as one source.
Change student content in the QMD and teaching instructions in that JSON.

## The self-referential type

Before allocating the first node, use **Can we use the alias here?** to ask for
a prediction, then compile the intentionally wrong declaration:

```sh
cp types/01-alias-too-early.c live-list.c
make program FILE=live-list.c
```

GCC reports `unknown type name ‘list_elem_t’`. Do not run an old executable after
a failed build. In Vim, replace `list_elem_t *next` with `struct list_elem *next`,
save and compile again. Recovery for the corrected version:

```sh
cp 00-empty.c live-list.c
make program FILE=live-list.c
```

Reload Vim with `:e!` after either copy. Explain the tag at the top, the pointer
member, and the alias at the bottom. The tag is available inside the definition;
the new typedef alias is not available at the member declaration. A pointer to
the incomplete struct is allowed, but an embedded struct would require its
finished size. CS50 uses `node` for both names; here they are `list_elem` and
`list_elem_t`. These are C naming and type rules, not a compiler bug.

References: [GNU C structures](https://www.gnu.org/software/c-intro-and-ref/manual/html_node/Structures.html),
[type tags](https://www.gnu.org/software/c-intro-and-ref/manual/html_node/Type-Tags.html),
and [typedef names](https://www.gnu.org/software/c-intro-and-ref/manual/html_node/Defining-Typedef-Names.html).

## Stack and heap steps (slides 31–34)

The section **2. Linked-list basics** sets the goal: build A -> B -> NULL in
main and traverse it without moving head. Each example names its part of that goal.

The C statement and explanation occupy the left column. The narrower right
column keeps one black memory grid in a fixed position. Addresses appear beside
cells, stored pointer values inside them. Blank rows and dots omit other memory
and separate A at 0x1000 from B at 0x3000. There are no drawn growth or pointer
arrows. Explain the stack/heap convention orally. Rows represent variables or
fields rather than equal byte counts; the addresses are illustrative.

Slide 31 creates only head. On slide 32, ask and run first, then advance through
malloc, value initialisation, next initialisation, and head assignment. Slide 33
repeats these steps for B before linking it through A's next. Slide 34 traces p
without changing head. Each step is an instant replacement, with no sliding or
object movement. Printed slides show the full code and final memory state.

## What the original CM covered

Source: CM/CM-all-2025.pptx, linked-list part 313–355.

| Original slides | Content |
|---|---|
| 314–316 | Arrays versus lists, benefits and costs, data and next members |
| 317–320 | Empty head, create_element, heap allocation, return address, head assignment |
| 321–327 | Updating the caller's head through its address; failure when only a pointer copy changes |
| 328–347 | Insert at the head, in the middle and at the tail; preserve links and use the correct assignment order |
| 348–354 | Delete at the head, in the middle and at the tail; retain the victim address and free it |
| 355 | Doubly linked lists: prev, backward traversal, extra storage and link maintenance |

All of these topics remain. The A/B program in main and its traversal are added
preparation for the original create_element and insert_head examples. The
Kahoot corrections and struct/typedef reminders are also opening review.
Hash tables start at 356 and are outside this deck.

### Questions with a visible list

For insertion, deletion and the doubly linked list comparison, each question
keeps the current diagram visible. Let students point to the relevant nodes
and propose the next assignment. One Right replaces the diagram in place and
reveals the code and conclusion together. On demonstration slides, run the
terminal example before revealing the result, as directed by the guide.
The printed handout shows the completed diagram. Slide numbers are unchanged.

### Closing questions

After the doubly linked list cost table, use section 8 for four A-D questions.
Collect answers before pressing Right. All choices remain visible; the answer
and explanation appear together. These are new linked-list questions, not the
allocation quiz at the start. No online quiz session is required.

Original slide 355 already compares traversal, deletion, memory overhead and
link maintenance. The playlist context, explicit asymptotic costs and final
four questions are additions. Singly linked predecessor search is O(n) only
when its address has not already been saved. Total storage is Theta(n) for both.
