"""Keep Quarto speaker notes and the printed guide on the same teaching cues."""
from pathlib import Path
import json
import html
import re

ROOT = Path(__file__).resolve().parents[1]

def sync_notes():
    path = ROOT / 'cours/01-allocation.qmd'
    source = path.read_text()
    cues = [cue for page in json.loads((ROOT / 'docs/allocation-teacher-cues.json').read_text())['pages'] for cue in page['cues']]
    chunks = re.split(r'(?=^#{1,2} .+ \{#[^}]+\}$)', source, flags=re.M)
    ids = [re.search(r'\{#([^ }]+)', chunk)[1] for chunk in chunks[1:]]
    assert [cue['id'] for cue in cues] == ['title-slide'] + ids, 'Cues must follow the slide order exactly'
    for index, cue in enumerate(cues[1:], 1):
        body = re.sub(r'\n::: \{\.notes\}\n.*?\n:::\s*$', '', chunks[index], flags=re.S).rstrip()
        notes = [f'**{cue["mode"]}**', html.escape(cue['do'], quote=False)]
        if cue['code']:
            notes.append('```c\n' + cue['code'] + '\n```')
        for key, label in [('expect', 'Expect'), ('reveal', 'Reveal'), ('context', 'Context')]:
            if cue.get(key):
                notes.append(f'**{label}:** {html.escape(cue[key], quote=False)}')
        chunks[index] = body + '\n\n::: {.notes}\n' + '\n\n'.join(notes) + '\n:::\n\n'
    result = ''.join(chunks).rstrip() + '\n'
    if result != source:
        path.write_text(result)

if __name__ == '__main__':
    sync_notes()
