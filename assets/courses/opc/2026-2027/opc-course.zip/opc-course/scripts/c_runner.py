"""Compile a complete C17 program, then run it in a fresh process.

For trusted, local teaching examples. This is not a sandbox.
"""
from dataclasses import dataclass
import argparse
import os
from pathlib import Path
import shlex
import signal
import subprocess
import tempfile


@dataclass
class Result:
    returncode: int
    stdout: str
    stderr: str
    command: str = ""


def run_process(command, *, cwd, stdin="", timeout=8, env=None):
    with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
        proc = subprocess.Popen(command, cwd=cwd, stdin=subprocess.PIPE,
                                stdout=out, stderr=err, env=env,
                                start_new_session=True)
        timed_out = False
        try:
            proc.communicate(stdin.encode(), timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(proc.pid, signal.SIGKILL)
            proc.communicate()
        out.seek(0)
        err.seek(0)
        def read(stream):
            data = stream.read(65537)
            return data[:65536].decode(errors="replace") + ("\n[output truncated]\n" if len(data) > 65536 else "")
        return Result(124 if timed_out else proc.returncode, read(out),
                      read(err) + ("\nExecution timed out.\n" if timed_out else ""))


def run_c(source, *, sanitize=False, valgrind=False, stdin=""):
    if sanitize and valgrind:
        raise ValueError("Choose Valgrind or sanitizers, not both.")
    compiler = shlex.split(os.environ.get("CC", "gcc"))
    flags = ["-std=c17", "-Wall", "-Wextra", "-Wpedantic", "-O0", "-g"]
    if sanitize:
        flags += ["-fsanitize=address,undefined", "-fno-omit-frame-pointer"]
    with tempfile.TemporaryDirectory(prefix="opc-c-") as directory:
        path = Path(directory)
        (path / "main.c").write_text(source)
        build = run_process(compiler + flags + ["main.c", "-o", "program"], cwd=path, timeout=30)
        build.command = shlex.join(compiler + flags + ["main.c", "-o", "program"])
        if build.returncode:
            return build
        env = dict(os.environ, ASAN_OPTIONS="detect_leaks=1:halt_on_error=1",
                   UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1")
        executable = [str(path / "program")]
        shown = "./program"
        if valgrind:
            options = ["--leak-check=full", "--track-origins=yes", "--error-exitcode=99"]
            executable = [str(Path(__file__).resolve().parent / "valgrind.sh")] + options + executable
            shown = shlex.join(["valgrind"] + options + ["./program"])
        result = run_process(executable, cwd=path, stdin=stdin, env=env,
                             timeout=30 if valgrind else 8)
        result.command = build.command + "\n" + shown
        result.stderr = build.stderr + result.stderr
        return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("file", type=Path)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--sanitize", action="store_true")
    mode.add_argument("--valgrind", action="store_true")
    args = parser.parse_args()
    result = run_c(args.file.read_text(), sanitize=args.sanitize, valgrind=args.valgrind)
    print(result.stdout, end="")
    print(result.stderr, end="", file=__import__("sys").stderr)
    raise SystemExit(result.returncode)
