"""Serve slides and live GCC examples on loopback. Trusted lecturer code only."""
import argparse
from dataclasses import asdict
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import json
from pathlib import Path
import secrets
import threading
from urllib.parse import parse_qs, urlsplit
from c_runner import run_c

ROOT = Path(__file__).resolve().parents[1]
TOKEN = secrets.token_urlsafe(32)
RUN_LOCK = threading.Lock()


class Presenter(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT / "cours/_output"), **kwargs)

    def json_response(self, status, data):
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def valid_origin(self):
        host = f"127.0.0.1:{self.server.server_port}"
        return self.headers.get("Host") == host and self.headers.get("Origin", "http://"+host) == "http://"+host

    def example_path(self, name):
        if not name or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-" for c in name):
            return None
        folder = ROOT / "demos" / name
        if not folder.is_dir():
            folder = ROOT / "demos/reference" / name
        manifest = folder / "steps.json"
        file = json.loads(manifest.read_text())[0]["file"] if manifest.is_file() else "main.c"
        path = folder / file
        return path if path.is_file() and not path.is_symlink() else None

    def do_GET(self):
        if not self.valid_origin():
            return self.json_response(403, {"error":"This presenter is local to 127.0.0.1."})
        route = urlsplit(self.path).path
        if route.startswith("/api/example/"):
            name = route.removeprefix("/api/example/")
            path = self.example_path(name)
            if path is None:
                return self.json_response(404, {"error":"Unknown example."})
            data = {"token": TOKEN, "mode": "valgrind" if name in {"02-dangling", "03-leak", "12-list-copy", "16-overrun", "17-uninitialised", "18-lost-allocation"} else "native", "stdin": "4\n" if name == "15-runtime-size" else "", "file": "main.c", "stage": "", "stages": []}
            requested = parse_qs(urlsplit(self.path).query).get("stage", [""])[0]
            manifest = path.parent / "steps.json"
            if manifest.is_file():
                steps = json.loads(manifest.read_text())
                selected = next((step for step in steps if step["id"] == (requested or steps[0]["id"])), None)
                if selected is None:
                    return self.json_response(404, {"error": "Unknown example step."})
                selected_path = path.parent / selected["file"]
                if not selected_path.resolve().is_relative_to(path.parent.resolve()) or not selected_path.is_file():
                    return self.json_response(404, {"error": "Missing example step."})
                path = selected_path
                data.update({key: selected[key] for key in ("mode", "stdin", "file")})
                data["stage"] = selected["id"]
                data["stages"] = [{"id": step["id"], "label": step["label"]} for step in steps]
            elif requested:
                return self.json_response(404, {"error": "This example has no steps."})
            data["source"] = path.read_text()
            return self.json_response(200, data)
        return super().do_GET()

    def do_POST(self):
        if not self.valid_origin() or not secrets.compare_digest(self.headers.get("X-Live-C-Token", ""), TOKEN):
            return self.json_response(403, {"error":"Invalid local session."})
        if self.path != "/api/run" or self.headers.get("Content-Type") != "application/json":
            return self.json_response(400, {"error":"Expected a JSON run request."})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 100000:
                raise ValueError("Request too large or empty.")
            data = json.loads(self.rfile.read(length))
            if not isinstance(data, dict) or self.example_path(data.get("example", "")) is None:
                raise ValueError("Unknown example.")
            source, stdin = data.get("source"), data.get("stdin", "")
            if not isinstance(source,str) or not isinstance(stdin,str) or len(source)>65536 or len(stdin)>8192:
                raise ValueError("Invalid source or standard input.")
            sanitize = data.get("sanitize", False)
            if not isinstance(sanitize,bool):
                raise ValueError("Invalid sanitizer option.")
            mode = data.get("mode", "sanitizers" if sanitize else "native")
            if mode not in {"native", "valgrind", "sanitizers"}:
                raise ValueError("Invalid execution mode.")
            if sanitize and mode != "sanitizers":
                raise ValueError("Conflicting execution modes.")
        except (ValueError, TypeError, AttributeError) as error:
            return self.json_response(400, {"error":str(error)})
        if not RUN_LOCK.acquire(blocking=False):
            return self.json_response(409, {"error":"An example is already running."})
        try:
            result = asdict(run_c(source, sanitize=mode == "sanitizers", valgrind=mode == "valgrind", stdin=stdin))
            return self.json_response(200, result)
        except OSError as error:
            return self.json_response(500, {"error":str(error)})
        finally:
            RUN_LOCK.release()


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port",type=int,default=8877)
    args=parser.parse_args()
    server=ThreadingHTTPServer(("127.0.0.1",args.port),Presenter)
    print(f"Slides + live C: http://127.0.0.1:{server.server_port}/01-allocation.html",flush=True)
    server.serve_forever()
