import {EditorState} from '@codemirror/state';
import {EditorView, keymap, lineNumbers, highlightActiveLineGutter} from '@codemirror/view';
import {defaultKeymap, history, historyKeymap, indentWithTab} from '@codemirror/commands';
import {StreamLanguage, syntaxHighlighting, HighlightStyle, indentUnit, bracketMatching} from '@codemirror/language';
import {c} from '@codemirror/legacy-modes/mode/clike';
import {tags} from '@lezer/highlight';

// Only the editor is bundled. GCC execution remains in the local Python server.
export function create(parent, onRun) {
  const extensions = [
    lineNumbers(), highlightActiveLineGutter(), history(), bracketMatching(),
    StreamLanguage.define(c), indentUnit.of('    '), EditorState.tabSize.of(4),
    EditorView.lineWrapping,
    keymap.of([
      {key: 'Mod-Enter', run: () => { onRun(); return true; }},
      indentWithTab, ...defaultKeymap, ...historyKeymap
    ]),
    EditorView.contentAttributes.of({
      'aria-label': 'C source — editable', spellcheck: 'false',
      autocorrect: 'off', autocapitalize: 'off'
    }),
    syntaxHighlighting(HighlightStyle.define([
      {tag: [tags.keyword, tags.typeName], color: '#003b80', fontWeight: '600'},
      {tag: [tags.string, tags.character], color: '#00502e'},
      {tag: tags.number, color: '#8b2200'},
      {tag: [tags.meta, tags.processingInstruction], color: '#6f1377'},
      {tag: tags.comment, color: '#444444'},
      {tag: tags.invalid, color: '#a0001c', textDecoration: 'underline'}
    ]))
  ];
  const view = new EditorView({state: EditorState.create({extensions}), parent});
  return {
    getValue: () => view.state.doc.toString(),
    setValue(text) { view.setState(EditorState.create({doc: text, extensions})); },
    focus() {
      view.requestMeasure();
      view.focus();
      view.dispatch({selection: {anchor: 0}, scrollIntoView: true});
    }
  };
}
