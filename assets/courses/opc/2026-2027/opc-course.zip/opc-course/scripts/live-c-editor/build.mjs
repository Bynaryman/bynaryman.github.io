import {build} from 'esbuild';
import {readFile, writeFile, appendFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const root = fileURLToPath(new URL('.', import.meta.url));
const output = new URL('../../cours/_extensions/live-c/', import.meta.url);
const result = await build({
  absWorkingDir: root,
  entryPoints: ['editor.js'], bundle: true, minify: true,
  format: 'iife', globalName: 'LiveCEditor', target: ['es2020'],
  outfile: fileURLToPath(new URL('editor.bundle.js', output)),
  metafile: true,
  banner: {js: '// CodeMirror editor bundle. Sources: scripts/live-c-editor/. See editor.LICENSE.txt.'}
});
// Include the complete licenses of all code actually shipped in the bundle.
const packages = new Set(Object.keys(result.metafile.inputs).map(path => {
  const parts = path.split('node_modules/')[1]?.split('/');
  return parts && (parts[0].startsWith('@') ? parts.slice(0, 2).join('/') : parts[0]);
}).filter(Boolean));
const notices = [];
for (const name of [...packages].sort()) {
  const dir = new URL(`node_modules/${name}/`, import.meta.url);
  const pkg = JSON.parse(await readFile(new URL('package.json', dir), 'utf8'));
  notices.push(`${name} ${pkg.version}\n\n${await readFile(new URL('LICENSE', dir), 'utf8')}`);
}
await writeFile(new URL('editor.LICENSE.txt', output), notices.join('\n\n---\n\n'));

// Keep license notices with the JS when Quarto copies only registered scripts.
await appendFile(new URL('editor.bundle.js', output), '\n/*\n' + notices.join('\n\n---\n\n') + '\n*/\n');
