"""Build the editable TikZ figures as matching SVG and PDF assets.

Requires LuaLaTeX with TikZ, fontspec and standalone; DejaVu fonts; and Poppler.
Pass figure stems to rebuild only those figures, e.g. `python scripts/diagrams.py array`.
"""
from concurrent.futures import ThreadPoolExecutor
import argparse
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'cours/figures'
OUTPUT = ROOT / 'cours/assets/diagrams'
BUILD = ROOT / 'build/tikz'


def build(source: Path) -> str:
    name = source.stem
    commands = [
        ['lualatex', '-interaction=nonstopmode', '-halt-on-error',
         f'-output-directory={BUILD}', source.name],
        ['pdftocairo', '-svg', str(BUILD / f'{name}.pdf'), str(OUTPUT / f'{name}.svg')],
    ]
    env = dict(os.environ, SOURCE_DATE_EPOCH='0', FORCE_SOURCE_DATE='1')
    for i, command in enumerate(commands):
        result = subprocess.run(command, cwd=SOURCE, env=env, capture_output=True, text=True)
        log = BUILD / f'{name}-{i}.log'
        log.write_text(result.stdout + result.stderr)
        if result.returncode:
            raise RuntimeError(f'{name}: see {log}\n' + (result.stdout + result.stderr)[-1800:])
    shutil.copyfile(BUILD / f'{name}.pdf', OUTPUT / f'{name}.pdf')
    return name


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('figures', nargs='*', help='Optional figure stems')
    args = parser.parse_args()
    for tool in ['lualatex', 'pdftocairo']:
        if not shutil.which(tool):
            raise SystemExit(f'Missing {tool}: install TeX Live / Poppler.')
    sources = sorted(p for p in SOURCE.glob('*.tex')
                     if not p.name.startswith('_') and p.stem != 'style')
    if args.figures:
        selected = set(args.figures)
        unknown = selected - {p.stem for p in sources}
        if unknown:
            raise SystemExit(f'Unknown figures: {sorted(unknown)}')
        sources = [p for p in sources if p.stem in selected]
    BUILD.mkdir(parents=True, exist_ok=True)
    OUTPUT.mkdir(parents=True, exist_ok=True)
    with ThreadPoolExecutor(max_workers=4) as pool:
        for name in pool.map(build, sources):
            print(f'TikZ → PDF / SVG: {name}', flush=True)
