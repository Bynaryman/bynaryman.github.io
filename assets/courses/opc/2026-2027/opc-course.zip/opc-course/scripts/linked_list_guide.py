#!/usr/bin/env python3
"""Synchronise linked-list speaker notes and build its printable teacher guide."""
from pathlib import Path
import argparse,html,json,re
ROOT=Path(__file__).resolve().parents[1]

def load_and_sync():
    path=ROOT/'cours/02-linked-lists.qmd'
    source=path.read_text()
    cues=json.loads((ROOT/'docs/linked-lists-teacher-cues.json').read_text())['cues']
    chunks=re.split(r'(?=^#{1,2} .+ \{#[^}]+\}$)',source,flags=re.M)
    ids=['title-slide']+[re.search(r'\{#([^ }]+)',c)[1] for c in chunks[1:]]
    assert ids==[c['id'] for c in cues]
    for i,c in enumerate(cues[1:],1):
        body=re.sub(r'\n::: \{\.notes\}\n.*?\n:::\s*$','',chunks[i],flags=re.S).rstrip()
        notes=[]
        for key,label in [('purpose','Purpose'),('do','Do'),('expect','Expect'),('reveal','Reveal')]:
            if c[key]:notes.append('**'+label+':** '+html.escape(c[key],quote=False))
        if c['checkpoint']:
            assert (ROOT/'demos/linked-lists'/c['checkpoint']).is_file()
            commands=['cp '+c['checkpoint']+' live-list.c']
            if c['run']:commands.append('make '+c['run']+' FILE=live-list.c')
            notes.append('**Recovery:**\n\n```sh\n'+'\n'.join(commands)+'\n```')
            notes.append('After copying from Vim, use :e! to reload. For normal edits use :w before running. If recovery supplies the complete operation, skip its edits; run only when this guide says to run.')
        else:notes.append('**Recovery:** No C change or run on this slide.')
        if c.get('review_source'):notes.append('**Kahoot source:** '+c['review_source']['file']+', page '+str(c['review_source']['page'])+'.')
        if c['source']:notes.append('**Source:** CM/CM-all-2025.pptx, '+', '.join(map(str,c['source']))+'.')
        chunks[i]=body+'\n\n::: {.notes}\n'+'\n\n'.join(notes)+'\n:::\n\n'
    result=''.join(chunks).rstrip()+'\n'
    if result!=source:path.write_text(result)
    return cues

def build(cues):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Preformatted,PageBreak,KeepTogether
    font=Path('/usr/share/fonts/TTF')
    if not (font/'DejaVuSans.ttf').exists():font=Path('/usr/share/fonts/truetype/dejavu')
    for name,file in [('Guide','DejaVuSans.ttf'),('GuideBold','DejaVuSans-Bold.ttf'),('GuideMono','DejaVuSansMono.ttf')]:pdfmetrics.registerFont(TTFont(name,str(font/file)))
    pdfmetrics.registerFontFamily('Guide',normal='Guide',bold='GuideBold',italic='Guide',boldItalic='GuideBold')
    styles={k:ParagraphStyle(k,fontName=f,fontSize=size,leading=lead,spaceAfter=6,textColor=colors.HexColor(col)) for k,f,size,lead,col in [('title','GuideBold',22,27,'#111111'),('head','GuideBold',12,16,'#003b80'),('body','Guide',10.5,14,'#111111'),('small','Guide',9,12,'#424242'),('code','GuideMono',9.3,12,'#111111')]}
    def clean(s):return s.replace('`','').replace('→','->').replace('–','-').replace('—','-')
    def esc(s):return html.escape(clean(s))
    def p(s,style='body'):return Paragraph(s,styles[style])
    def code(s):return Preformatted(s,styles['code'])
    story=[p('Linked lists','title'),p('Teacher guide / continuation of structures and dynamic memory','head'),p(f'{len(cues)} slides. Source: CM/CM-all-2025.pptx, slides 313-355. The opening also reviews all ten screenshots in CM/Untitled document-1.pdf, then recalls struct and typedef. Hash tables are excluded.'),p('Teaching rhythm','head'),p('State the purpose, ask for a prediction, edit C in Vim, run in the terminal, then return to Reveal for the explanation. Right reveals an explanation or advances to the next statement in a memory trace. There are no per-slide timings.'),p('Before class','head'),code('firefox cours/_output/02-linked-lists.html\ncd demos/linked-lists\ncp -n 00-empty.c live-list.c\nvim live-list.c'),p('The -n option preserves a rehearsal file. Inspect it before class. Use one working file, live-list.c. Save with :w before make. No browser C plugin is needed.'),p('Recovery','head'),p('Each relevant slide prints a cp command. It replaces live-list.c with the stated reference. In Vim, prefix cp with :!, then reload with :e!. Do not save the old buffer over the copied file.'),code(':!cp 07-head-fixed.c live-list.c\n:e!\n:!make valgrind FILE=live-list.c'),p('A recovery file may contain the complete operation while the slides explain its individual statements. Skip edits already present and wait for the stated run point. Wrong examples deliberately leak; a nonzero Make result is expected. Read the Valgrind report.'),p('The C examples','head'),p('First manipulate the drawn playlist. Then intro/01-one-node.c builds A in main, intro/02-two-nodes.c links B, and intro/03-walk.c follows next. Only then extract create_element. All examples store song IDs A-E as integer character constants and print them with %c. Every later operation resets to the pictured chain.'),p('Memory states','head'),p('Call traces keep named stack frames and heap objects in fixed positions. Boxes store values; arrows follow addresses. Each Right advances one state. Diagrams stop before final cleanup; the runnable example then frees the reachable list. Operation diagrams initialise next to NULL just like the code. Only the raw malloc trace uses ? for uninitialised fields.'),PageBreak(),p('Page map','title')]
    groups=[cues[i:i+3] for i in range(0,len(cues),3)]
    for index,group in enumerate(groups,3):
        first=cues.index(group[0])+1;last=first+len(group)-1
        story.append(p(f'<b>{index}</b> / Slides {first}-{last}: {esc(group[0]["title"])}','small'))
    story.extend([p('Lesson order','head'),p('Finish Kahoot corrections and the Struct reminder. Demonstrate the playlist edits visually, build two nodes in main, then introduce helper functions. Ask for a prediction before each terminal run. Reveal the explanation afterwards. The guide names the reference file and run point for every demonstration.'),p('Intentional failures','head'),p('03-head-copy: caller head stays NULL; one node leaks. 06-head-lost: A-D become unreachable. 09-middle-lost: C-D become unreachable. Read Valgrind, then reset to the indicated checkpoint before repairing the operation.')])
    for index,group in enumerate(groups):
        story.append(PageBreak())
        for offset,c in enumerate(group):
            n=index*3+offset+1
            items=[p(f'{n:02d} / {esc(c["title"])}','head')]
            for key,label in [('purpose','Purpose'),('do','Do'),('expect','Expect'),('reveal','Reveal')]:
                if c[key]:items.append(p('<b>'+label+':</b> '+esc(c[key])))
            if c['checkpoint']:
                commands=['cp '+c['checkpoint']+' live-list.c']
                if c['run']:commands.append('make '+c['run']+' FILE=live-list.c')
                items.extend([p('Recovery:','small'),code('\n'.join(commands))])
            else:items.append(p('No C change or run.','small'))
            if offset==len(group)-1 and n<len(cues):items.append(p('Next: '+str(n+1)+' / '+esc(cues[n]['title']),'small'))
            story.append(KeepTogether(items))
    def footer(canvas,doc):
        canvas.setFont('Guide',8.5);canvas.setFillColor(colors.HexColor('#424242'))
        canvas.drawString(18*mm,A4[1]-12*mm,'OPC / Linked lists / Teacher copy')
        canvas.drawString(18*mm,11*mm,'Louis Ledoux / 2026-2027')
        canvas.drawRightString(A4[0]-18*mm,11*mm,str(doc.page))
    out=ROOT/'output/pdf/linked-lists-teacher-guide.pdf';out.parent.mkdir(parents=True,exist_ok=True)
    doc=SimpleDocTemplate(str(out),pagesize=A4,rightMargin=18*mm,leftMargin=18*mm,topMargin=21*mm,bottomMargin=19*mm,title='Linked lists - Teacher guide',author='Louis Ledoux')
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    assert doc.page==len(groups)+2, f'Guide overflow: {doc.page} pages, expected {len(groups)+2}'
    print(f'{out}: {doc.page} pages')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--notes-only',action='store_true');args=parser.parse_args()
    cues=load_and_sync()
    if not args.notes_only:build(cues)
