#!/bin/sh
# Prefer the system tool. Local tools/debug data are optional and untracked.
runner_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
if command -v valgrind >/dev/null 2>&1; then
    runner_bin=$(command -v valgrind)
else
    for runner_prefix in "$runner_root/build/tools/valgrind-new/usr" "$runner_root/build/tools/valgrind/usr"; do
        if [ -x "$runner_prefix/bin/valgrind" ]; then
            runner_bin="$runner_prefix/bin/valgrind"
            if [ -d "$runner_prefix/libexec/valgrind" ]; then
                export VALGRIND_LIB="$runner_prefix/libexec/valgrind"
            else
                export VALGRIND_LIB="$runner_prefix/lib/valgrind"
            fi
            break
        fi
    done
fi
if [ -z "$runner_bin" ]; then
    printf '%s\n' 'Valgrind is not installed. Install the valgrind package for your system.' >&2
    exit 127
fi
if [ -d "$runner_root/build/tools/debug" ]; then
    set -- "--extra-debuginfo-path=$runner_root/build/tools/debug" "$@"
fi
exec "$runner_bin" "$@"
