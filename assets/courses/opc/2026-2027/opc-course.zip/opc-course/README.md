# OPC · C programming

Louis Ledoux · ISTIC, University of Rennes · 2026–2027

English adaptation of A. Kritikakou's OPC teaching material. Allocation and
user-defined types follow CM/CM-all-2025.pptx, slides 281–312.
Original PowerPoints are not included in this bundle.
See cours/SOURCE-MAP.md for coverage and cours/assets/ATTRIBUTIONS.md for credits.
Original authorship is retained; this bundle does not grant a new blanket licence.

## Present and run C

Open cours/_output/01-allocation.html in Firefox. No server is needed.
Install GCC, Make and Valgrind on Linux or WSL, then run:

```sh
cd demos/00-allocation
vim main.c
make run
vim checkpoints/03-heap.c
make run STEP=03-heap       # Enter 100
make valgrind STEP=04-overrun  # Enter 4; an error is expected
```

Each slide shows its source file and command. Run the command inside that
example's folder. See demos/00-allocation/README.md for the saved versions,
and docs/allocation-runbook.md for the 90-minute sequence and repairs.

## Rebuild or print

Rendered slides and PDFs are included. To rebuild, install Quarto and run
make slides. PDF rendering (make pdf) also requires LuaLaTeX, Beamer and the
DejaVu fonts. To change diagrams, edit cours/figures and run make figures
(Python 3, LuaLaTeX, TikZ and Poppler required).

PDFs have one slide per page. Select four pages per sheet when printing.
