# OPC · C programming

Louis Ledoux · ISTIC, University of Rennes · 2026–2027

English adaptation of A. Kritikakou's OPC teaching material. Allocation and
user-defined types follow CM/CM-all-2025.pptx, slides 281–312.
Original PowerPoints are not included in this bundle.
See cours/SOURCE-MAP.md for coverage and cours/assets/ATTRIBUTIONS.md for credits.
Original authorship is retained; this bundle does not grant a new blanket licence.

## Start the slides and live C

On Linux or WSL, install Python 3, GCC, Make and Valgrind using your system's
package manager. From this extracted opc-course directory, run:

```sh
make serve
```

Open http://127.0.0.1:8877/01-allocation.html. Keep the terminal running; Ctrl+C stops
it. Choose Run live C, edit the highlighted C source, and Compile & run (Ctrl+Enter).
Select Valgrind for memory diagnostics. Each run compiles a fresh native program.
The local presenter executes trusted code as your user; it is not a sandbox.
Save permanent edits in demos/<example>/main.c; browser edits are temporary.

You can also run examples in a terminal, from this course directory:

```sh
cd demos/00-allocation
vim main.c
make run
make valgrind
```

Start with the four-element array in main.c. The Step menu and
demos/00-allocation/README.md give seven saved versions of the same program.
To run a checkpoint in the terminal, use make run STEP=03-heap and enter 100.

Some examples deliberately contain errors. See their README files and
docs/allocation-runbook.md for the intended investigation and repair sequence.

## View or rebuild

For static viewing, open the HTML or PDFs in cours/_output. PDFs contain one slide
per page; your PDF viewer can print four pages per sheet. Static HTML opened as
a file displays the slides, but live C requires the presenter above.

Rendered slides are included: Quarto is not required for make serve.
To rebuild, install Quarto and run make slides, or make present to rebuild and
start the presenter. PDF rendering (make pdf) additionally requires LuaLaTeX,
Beamer, DejaVu Sans and DejaVu Sans Mono. To change a diagram, edit its TikZ source
under cours/figures and run make figures (LuaLaTeX, TikZ and Poppler required).
The C editor is already bundled; rebuilding it is documented in
cours/_extensions/live-c/README.md.
