# OPC · C programming

Louis Ledoux · ISTIC, University of Rennes · 2026–2027

## Slides and C examples

Open cours/_output/01-allocation.html in Firefox. No server is needed.
Use demos/allocation/README.md: files 01 through 18 are in lecture order.
Install GCC, Make and Valgrind on Linux or WSL, then run:

```sh
cd demos/allocation
vim 01-copy-alias.c
make run FILE=01-copy-alias.c
```

Open the next numbered file and pass the same filename to Make.
For example: make valgrind FILE=08-dangling.c (enter 4).
Files 01–04 develop a string copy, fixing its size and then its leak.
File 05 introduces integers; 06–09 each introduce one fault into 05-integers.c.
Repair and rerun each before continuing. See docs/allocation-runbook.md.

## Rebuild or print

Rendered HTML and PDF are included. Rebuild with Quarto: make slides.
PDF rendering also needs LuaLaTeX, Beamer and DejaVu fonts: make pdf.
Edit TikZ diagrams in cours/figures and run make figures (Poppler required).
The PDF has one slide per page; choose four pages per sheet when printing.

## Sources

Required content: A. Kritikakou's CM/CM-all-2025.pptx, slides 281–312.
See cours/SOURCE-MAP.md and cours/assets/ATTRIBUTIONS.md. Original authorship
is retained; this bundle does not grant a new blanket licence.
Original PowerPoints are not included.
