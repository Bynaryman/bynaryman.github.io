# 05-string

A four-byte allocation stores three letters plus the null terminator. Predict the fourth byte. Try a longer word with sanitizers.

```sh
vim main.c
make run
make sanitize
```

Browser edits are temporary. Edit `main.c` here to keep changes in Git.
