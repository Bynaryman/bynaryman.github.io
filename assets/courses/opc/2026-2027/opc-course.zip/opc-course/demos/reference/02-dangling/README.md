# 02-dangling

Intentional use after free. Run with sanitizers. Move the read before free and rerun. Undefined behaviour has no predictable output.

```sh
vim main.c
make run
make sanitize
```

Browser edits are temporary. Edit `main.c` here to keep changes in Git.
