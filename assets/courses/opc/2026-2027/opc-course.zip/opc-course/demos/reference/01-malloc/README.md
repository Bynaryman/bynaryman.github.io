# 01-malloc

Original CM7 example: allocate and initialise 100 integers. Change the size or initial values; predict before compiling.

```sh
vim main.c
make run
make sanitize
```

Browser edits are temporary. Edit `main.c` here to keep changes in Git.
