# Enumerations and structure members

Run `make run`. Read the definitions first, predict the four output lines,
then execute. `today` prints 2. The address starts at 12 Paul Bert, changes to
14 Rue de Paris through `home`, then to 16 Rue de Paris through `p`.

Change `p->number` to `(*p).number` and rerun: both access the same member.
The pointer refers to `home`; no structure is copied by `p = &home`.

Use the enum, structure, initialization, dot and arrow slides afterward to
explain the syntax. Compare layout with `../09-struct-padding/main.c` and nested
types with `../10-nested-struct/main.c`.
