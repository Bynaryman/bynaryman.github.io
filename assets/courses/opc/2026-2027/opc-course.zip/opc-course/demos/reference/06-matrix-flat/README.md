# 06-matrix-flat

Original 4 by 3 matrix as one block. Change a row/column and predict the linear index. One allocation, one free.

```sh
vim main.c
make run
make sanitize
```

Browser edits are temporary. Edit `main.c` here to keep changes in Git.
