# 03-leak

Original pointer reassignment example, with its leak made explicit. Run with sanitizers. Fix by copying text into the allocation and freeing its address, or use only literal pointers if no allocation is needed.

```sh
vim main.c
make run
make sanitize
```

Browser edits are temporary. Edit `main.c` here to keep changes in Git.
