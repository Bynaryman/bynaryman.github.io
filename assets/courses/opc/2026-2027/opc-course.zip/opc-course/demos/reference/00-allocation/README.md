# One program, then its repairs

Open `main.c` in Vim. Ask what must change to store 100 integers instead of four.
Keep editing that file while teaching. These saved versions let you inspect a
change or resume the demonstration without overwriting your working file.

| File | Question or change |
|:--|:--|
| [main.c](main.c) | Four integers: where is the capacity chosen? |
| [02-capacity.c](checkpoints/02-capacity.c) | Enter 100. Does reading a count enlarge p[4]? |
| [03-missing-free.c](checkpoints/03-missing-free.c) | Allocate by count; output is correct. What does Valgrind report? |
| [03-heap.c](checkpoints/03-heap.c) | Add free after printf; rerun and check that the leak is gone. |
| [05-uninitialised.c](checkpoints/05-uninitialised.c) | Remove the loop; diagnose the reads, restore the loop and rerun. |
| [04-overrun.c](checkpoints/04-overrun.c) | Change < to <=; diagnose the write and repair the bound. |
| [07-dangling.c](checkpoints/07-dangling.c) | Free before printf; diagnose the reads and move free back. |
| [06-leak.c](checkpoints/06-leak.c) | Lose the address before free; preserve it until release. |

```sh
vim main.c
make run
```

To inspect and run a saved version, from this folder:

```sh
vim checkpoints/03-missing-free.c
make run STEP=03-missing-free
make valgrind STEP=03-missing-free
# Enter 100 in each run. Valgrind reports a leak.
```

Add `free(p);` after printf in Vim and rerun the same command. The saved repaired
version is `03-heap.c`. A detected error gives a nonzero make exit; that is expected
for a deliberately faulty version.

Start each later fault from clean `03-heap.c`, using input 4. Predict, run,
inspect, repair, rerun, then explain with the slides. The initialization slide
belongs after the uninitialized read; free belongs after the unreleased block.

Counts and indices use int/%d, with count restricted to 1–1000. Allocations use
sizeof(int). Some C implementations support variable-length automatic arrays;
here heap storage makes allocation-failure handling and lifetime explicit.
The original fixed-100 program remains in `../01-malloc/main.c`.
