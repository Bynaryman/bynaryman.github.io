# 15-runtime-size

See [the lecture runbook](../../docs/allocation-runbook.md).

`make run` executes the program; `make valgrind` inspects its memory use.
