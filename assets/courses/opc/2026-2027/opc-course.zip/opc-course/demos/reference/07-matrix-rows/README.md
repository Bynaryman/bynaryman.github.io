# 07-matrix-rows

Four automatic row pointers, four separately allocated rows. The full program handles partial allocation failure. Which objects need free?

```sh
vim main.c
make run
make sanitize
```

Browser edits are temporary. Edit `main.c` here to keep changes in Git.
