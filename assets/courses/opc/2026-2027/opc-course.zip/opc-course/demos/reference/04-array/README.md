# 04-array

Four consecutive integers. Predict the difference between neighbouring addresses, then compare with sizeof(int).

```sh
vim main.c
make run
make sanitize
```

Browser edits are temporary. Edit `main.c` here to keep changes in Git.
