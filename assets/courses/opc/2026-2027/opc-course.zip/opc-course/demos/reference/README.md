# Reference examples

These are earlier standalone versions and the original 100-integer program.
They are not the lecture order. Use [../allocation/README.md](../allocation/README.md).
