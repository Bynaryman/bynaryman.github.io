#include <stdio.h>
#include <stdlib.h>
int main(void) {
    // slide:runtime:begin
    int count;
    if (scanf("%d", &count) != 1) return EXIT_FAILURE;
    if (count <= 0 || count > 1000) return EXIT_FAILURE;
    int *p = malloc(count * sizeof(int));
    if (p == NULL) return EXIT_FAILURE;
    // slide:runtime:end
    for (int i = 0; i < count; ++i) p[i] = (int)i;
    printf("Allocated %d bytes for %d integers\n", (int)(count * sizeof(int)), count);
    free(p);
    return EXIT_SUCCESS;
}
