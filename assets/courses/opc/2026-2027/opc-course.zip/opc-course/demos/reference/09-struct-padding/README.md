# 09-struct-padding

Same members, different order. Predict 16 versus 20 bytes on the illustrated ABI; verify using sizeof and offsetof. Layout is implementation-dependent; packed_order is only a name, not a packing attribute.

```sh
vim main.c
make run
make sanitize
```

Browser edits are temporary. Edit `main.c` here to keep changes in Git.
