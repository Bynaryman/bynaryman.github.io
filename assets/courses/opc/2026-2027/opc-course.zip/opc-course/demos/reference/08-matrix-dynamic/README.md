# 08-matrix-dynamic

Both the pointer table and rows are allocated. Count five malloc calls and five free calls. Free rows before the table.

```sh
vim main.c
make run
make sanitize
```

Browser edits are temporary. Edit `main.c` here to keep changes in Git.
