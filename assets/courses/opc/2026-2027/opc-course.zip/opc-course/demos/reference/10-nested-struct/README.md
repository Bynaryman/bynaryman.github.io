# 10-nested-struct

Original nested date example with English names. Follow . and -> to the same object; predict which assignment changes today.

```sh
vim main.c
make run
make sanitize
```

Browser edits are temporary. Edit `main.c` here to keep changes in Git.
