CC = gcc
CFLAGS = -std=c17 -Wall -Wextra -Wpedantic -O0 -g
.PHONY: run sanitize clean
program: main.c
	$(CC) $(CFLAGS) $< -o $@
run: program
	./program
sanitize:
	$(CC) $(CFLAGS) -fsanitize=address,undefined -fno-omit-frame-pointer main.c -o program-asan
	ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 ./program-asan
valgrind: program
	../../scripts/valgrind.sh --leak-check=full --track-origins=yes --error-exitcode=99 ./program

clean:
	rm -f program program-asan

.PHONY: run sanitize valgrind clean
