# Allocation lecture: file order

Stay in this folder. Follow **01 → 17**; the numbers are the lecture order.
Each file is a complete C program. There is no checkpoints subfolder.

This course uses fixed-size arrays and `malloc`. Variable-length arrays are outside
its scope; the Makefile rejects them with `-Werror=vla`.

For a scratchpad, use `make run FILE=scatchpad.c`. The filename need not be in the
lecture sequence. The equivalent direct compiler command is:

```sh
gcc -std=c17 -Wall -Wextra -Wpedantic -Werror=vla -O0 -g scatchpad.c -o scatchpad
```

```sh
cd demos/allocation
vim 01-fixed-array.c
make run FILE=01-fixed-array.c
```

Files 01–04 develop the same program. Files 05–08 each introduce **one independent
fault into 04-free.c**. Repair and rerun each fault before opening the next file.
Use 04-free.c to compare with the working version; do not accumulate the faults.

## Allocate an array

| File | What to do | Command |
| --- | --- | --- |
| [01-fixed-array.c](01-fixed-array.c) | Four integers. | `make run FILE=01-fixed-array.c` |
| [02-capacity.c](02-capacity.c) | Read a count; the array still holds four; enter **100**. | `make run FILE=02-capacity.c` |
| [03-missing-free.c](03-missing-free.c) | Allocate by count; find the missing release; enter **100**. | `make valgrind FILE=03-missing-free.c` |
| [04-free.c](04-free.c) | Release after the final read; enter **100**. | `make valgrind FILE=04-free.c` |

## Memory errors

| File | What to do | Command |
| --- | --- | --- |
| [05-uninitialised.c](05-uninitialised.c) | Remove initialisation; inspect the read; enter **4**. | `make valgrind FILE=05-uninitialised.c` |
| [06-overrun.c](06-overrun.c) | Write one element too far; enter **4**. | `make valgrind FILE=06-overrun.c` |
| [07-dangling.c](07-dangling.c) | Read after free; enter **4**. | `make valgrind FILE=07-dangling.c` |
| [08-leak.c](08-leak.c) | Lose the address before free; enter **4**. | `make valgrind FILE=08-leak.c` |

## Arrays, strings and matrices

| File | What to do | Command |
| --- | --- | --- |
| [09-array.c](09-array.c) | Array elements and their addresses. | `make run FILE=09-array.c` |
| [10-string.c](10-string.c) | Characters and the terminator. | `make run FILE=10-string.c` |
| [11-string-assignment.c](11-string-assignment.c) | Pointer assignment is not copying text. | `make valgrind FILE=11-string-assignment.c` |
| [12-matrix-flat.c](12-matrix-flat.c) | Matrix in one allocation. | `make run FILE=12-matrix-flat.c` |
| [13-matrix-rows.c](13-matrix-rows.c) | Fixed pointer table; allocated rows. | `make run FILE=13-matrix-rows.c` |
| [14-matrix-dynamic.c](14-matrix-dynamic.c) | Allocated pointer table and rows. | `make run FILE=14-matrix-dynamic.c` |

## User-defined types

| File | What to do | Command |
| --- | --- | --- |
| [15-types.c](15-types.c) | Enumerations and structure members. | `make run FILE=15-types.c` |
| [16-padding.c](16-padding.c) | Measure structure sizes and offsets. | `make run FILE=16-padding.c` |
| [17-nested.c](17-nested.c) | Nested structures. | `make run FILE=17-nested.c` |

For 03, run normally first, then run Valgrind. For 05–08, predict, run Valgrind,
read its diagnostic, edit the file in Vim, and rerun the **same command**.
A nonzero make exit is expected while the intentional error remains.

- 05: restore the initialization loop before printf.
- 06: replace `<= count` with `< count`.
- 07: move free after printf.
- 08: free the block before clearing its pointer.
- 11: copy the string into the allocation and release it after use.

Files 12–14 compare matrix layouts; they are not three more allocation lessons.
Files 15–17 cover the user-defined types included in the original CM.
Earlier standalone examples are kept under `../reference/`; they are not extra
steps. Linked-list examples belong to the next lecture.
