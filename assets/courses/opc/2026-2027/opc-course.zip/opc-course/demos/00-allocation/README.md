# Start here: an array whose size comes from the user

Open `main.c` in your editor and run `make run`. It stores four integers.
Keep editing this program during the lecture. The files in `checkpoints/`
are saved versions to compare with or resume from.

| Step | File | Run, change, explain |
| --- | --- | --- |
| 1 | [main.c](main.c) | Run the fixed array. Ask what happens if we need 100 integers. |
| 2 | [02-capacity.c](checkpoints/02-capacity.c) | Read the count. Input 4 works; 100 is rejected because `p[4]` still has four elements. |
| 3 | [03-heap.c](checkpoints/03-heap.c) | Replace `int p[4]` with `malloc`, check the result, keep the loop, and add `free` after use. Input 100 now works. |
| 4 | [04-overrun.c](checkpoints/04-overrun.c) | From step 3, change `< count` to `<= count`. Run Valgrind; repair the comparison. |
| 5 | [05-uninitialised.c](checkpoints/05-uninitialised.c) | From step 3, remove the initialization loop. Run Valgrind; restore it. |
| 6 | [06-leak.c](checkpoints/06-leak.c) | From step 3, put `p = NULL` before `free(p)`. Run Valgrind; move the assignment after the release. |
| 7 | [07-dangling.c](checkpoints/07-dangling.c) | From step 3, move `free(p)` before `printf`. Run Valgrind; move it back after the last read. |

Steps 4–7 each contain **one independent fault**, based on the clean step 3.
The loop and output stay the same, so students can identify the changed rule.

```sh
vim main.c
make run
make valgrind
```

To run a saved version without replacing your edits:

```sh
make run STEP=03-heap
# Enter 100 when the program waits for input.
make valgrind STEP=04-overrun
# Enter 4. An error and a nonzero make exit are expected.
```

To inspect or edit a checkpoint, open its file directly:

```sh
vim checkpoints/03-heap.c
make run STEP=03-heap
```

Run these commands inside `demos/00-allocation`, not from the course root.
Counts and loop indices use `int` and `%d`; allocations use `sizeof(int)`.

After the working allocation, use the slides to explain the byte count, pointer,
heap block, lifetime, and release. The original fixed 100-integer example is in
`../01-malloc/main.c` and uses the same allocation/check/initialize/free pattern.

Runtime size alone does not imply that malloc is the only solution: some C
implementations support variable-length automatic arrays. Here we choose heap
storage for explicit allocation-failure handling and a lifetime controlled by
`free`. The 1000-element limit keeps this demonstration's input and size bounded.
