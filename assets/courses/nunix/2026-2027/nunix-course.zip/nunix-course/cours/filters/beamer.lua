-- Preserve the course's blocks, emphasis and columns in the printed slides.
if not FORMAT:match("beamer") then return {} end

local function wrap(content, opening, closing)
  content:insert(1, pandoc.RawBlock("latex", opening))
  content:insert(pandoc.RawBlock("latex", closing))
  return content
end

function Header(header)
  if header.level == 1 then header.level = 2 end
  return header
end

function Image(image)
  if image.src:match("%.svg$") then
    image.src = image.src:gsub("%.svg$", ".pdf")
    if image.classes:includes("device-icon") then
      image.attributes.width = "10mm"
    else
      image.attributes.width = "100%"
      image.attributes.height = "50mm"
    end
  end
  return image
end

function Table(tbl)
  local layouts = { [2] = {0.36, 0.64}, [3] = {0.25, 0.40, 0.35}, [4] = {0.12, 0.36, 0.20, 0.32} }
  local widths = layouts[#tbl.colspecs] or {}
  local specified = false
  for _, col in ipairs(tbl.colspecs) do
    if (col[2] or 0) > 0 then specified = true end
  end
  if not specified then
    for i, col in ipairs(tbl.colspecs) do col[2] = widths[i] or 1 / #tbl.colspecs end
  end
  return wrap(pandoc.List({tbl}), "{\\small", "}")
end

function Div(div)
  if div.classes:includes("notes") then return {} end
  if div.classes:includes("evidence-grid") then
    div.classes = pandoc.List({"columns"})
    for _, child in ipairs(div.content) do
      if child.t == "Div" then
        child.classes:insert("column")
        child.attributes.width = "31%"
      end
    end
  elseif div.classes:includes("column") and not div.attributes.width then
    div.attributes.width = "48%"
  elseif div.classes:includes("evidence-card") then
    local colour = div.classes:includes("developer-evidence") and "MarkerPlumInk" or
      (div.classes:includes("compute-evidence") and "MarkerGoldInk" or "CourseGreen")
    div.content = wrap(div.content,
      "\\begin{tcolorbox}[enhanced,colback=" .. colour .. "!4,colframe=CourseInk," ..
      "boxrule=.4pt,sharp corners,boxsep=1mm,left=1mm,right=1mm,top=1mm,bottom=1mm," ..
      "shadow={1mm}{-1mm}{0mm}{fill=black!28}]\\footnotesize",
      "\\end{tcolorbox}")
  elseif div.classes:includes("block") or div.classes:includes("answer-panel") then
    local colour = div.classes:includes("alert") and "CourseRed" or
      ((div.classes:includes("example") or div.classes:includes("answer-panel")) and "CourseGreen" or "CourseBlue")
    div.content = wrap(div.content,
      "\\begin{tcolorbox}[enhanced,colback=" .. colour .. "!4,colframe=" .. colour ..
      ",boxrule=.4pt,sharp corners,boxsep=1mm,left=1mm,right=1mm,top=1mm,bottom=1mm," ..
      "before skip=1mm,after skip=2mm,shadow={1mm}{-1mm}{0mm}{fill=black!28}]",
      "\\end{tcolorbox}")
  elseif div.classes:includes("small-note") then
    div.content = wrap(div.content, "{\\footnotesize", "\\par}")
  end
  return div
end

function Link(link)
  if link.classes:includes("stat-source") then
    link.content:insert(1, pandoc.RawInline("latex", "{\\scriptsize "))
    link.content:insert(pandoc.RawInline("latex", "}"))
  end
  return link
end

function Span(span)
  if span.classes:includes("marker") then
    local colour = "Green"
    if span.classes:includes("marker-plum") then colour = "Plum" end
    if span.classes:includes("marker-gold") then colour = "Gold" end
    if span.classes:includes("marker-red") then colour = "Red" end
    span.content:insert(1, pandoc.RawInline("latex", "\\CourseMarker{Marker" .. colour .. "Fill}{Marker" .. colour .. "Ink}{"))
    span.content:insert(pandoc.RawInline("latex", "}"))
  elseif span.classes:includes("stat-value") then
    span.content:insert(1, pandoc.RawInline("latex", "{\\Large\\bfseries "))
    span.content:insert(pandoc.RawInline("latex", "}"))
  elseif span.classes:includes("stat-heading") then
    span.content:insert(1, pandoc.RawInline("latex", "{\\color{CourseBlue}\\bfseries "))
    span.content:insert(pandoc.RawInline("latex", "}"))
  elseif span.classes:includes("stat-source") then
    span.content:insert(1, pandoc.RawInline("latex", "{\\scriptsize "))
    span.content:insert(pandoc.RawInline("latex", "}"))
  end
  return span
end
