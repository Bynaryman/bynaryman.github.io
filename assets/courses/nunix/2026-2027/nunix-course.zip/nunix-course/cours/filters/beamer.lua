-- Preserve the course's blocks, emphasis and columns in the printed slides.
if not FORMAT:match("beamer") then return {} end

local function wrap(content, opening, closing)
  content:insert(1, pandoc.RawBlock("latex", opening))
  content:insert(pandoc.RawBlock("latex", closing))
  return content
end

-- Keep section questions on a distinct divider, rather than a normal frame.
function Pandoc(document)
  local blocks = pandoc.List()
  local index = 1
  local function latex(inlines)
    return pandoc.write(pandoc.Pandoc({pandoc.Plain(inlines)}), "latex")
  end
  while index <= #document.blocks do
    local block = document.blocks[index]
    if block.t == "Header" and block.level == 1 then
      local question = ""
      local following = document.blocks[index + 1]
      if following and following.t == "Para" then
        question = latex(following.content)
        index = index + 1
      end
      blocks:insert(pandoc.Header(2, {}, block.attr))
      blocks:insert(pandoc.RawBlock("latex", "\\CourseSection{" .. latex(block.content) .. "}{" .. question .. "}"))
    else
      blocks:insert(block)
    end
    index = index + 1
  end
  document.blocks = blocks
  return document
end

function Header(header)
  if header.level == 2 and header.classes:includes("pipeline-preview") then
    return {header, pandoc.RawBlock("latex", "\\small")}
  end
end

function Image(image)
  if image.src:match("%.svg$") then
    image.src = image.src:gsub("%.svg$", ".pdf")
    if image.classes:includes("device-icon") then
      image.attributes.width = "10mm"
    else
      image.attributes.width = image.attributes.width or "100%"
      image.attributes.height = image.attributes.height or "50mm"
    end
  end
  if image.classes:includes("os-diagram") then
    image.attributes.width = "88%"
    image.attributes.height = nil
  elseif image.classes:includes("terminal-photo") then
    image.attributes.width = "88%"
    image.attributes.height = nil
  end
  return image
end

function Table(tbl)
  local layouts = { [2] = {0.36, 0.64}, [3] = {0.25, 0.40, 0.35}, [4] = {0.12, 0.36, 0.20, 0.32} }
  local widths = layouts[#tbl.colspecs] or {}
  local specified = false
  for _, col in ipairs(tbl.colspecs) do
    if (col[2] or 0) > 0 then specified = true end
  end
  if not specified then
    for i, col in ipairs(tbl.colspecs) do col[2] = widths[i] or 1 / #tbl.colspecs end
  end
  return wrap(pandoc.List({tbl}), "{\\small\\renewcommand{\\arraystretch}{1.15}\\setlength{\\LTpre}{2mm}\\setlength{\\LTpost}{3mm}", "}")
end

function Div(div)
  if div.classes:includes("notes") then return {} end
  if div.classes:includes("evidence-grid") then
    div.classes = pandoc.List({"columns"})
    for _, child in ipairs(div.content) do
      if child.t == "Div" then
        child.classes:insert("column")
        child.attributes.width = "31%"
      end
    end
  elseif div.classes:includes("column") and not div.attributes.width then
    div.attributes.width = "47%"
  elseif div.classes:includes("evidence-card") then
    local colour = div.classes:includes("developer-evidence") and "MarkerPlumInk" or
      (div.classes:includes("compute-evidence") and "MarkerGoldInk" or "CourseGreen")
    div.content = wrap(div.content,
      "\\begin{tcolorbox}[enhanced,colback=" .. colour .. "!4,colframe=CourseInk," ..
      "boxrule=.4pt,sharp corners,boxsep=1mm,left=1mm,right=1mm,top=1mm,bottom=1mm," ..
      "shadow={1mm}{-1mm}{0mm}{fill=black!28}]\\footnotesize",
      "\\end{tcolorbox}")
  elseif div.classes:includes("annotated-command") then
    div.content = wrap(div.content,
      "\\begin{tcolorbox}[enhanced,colback=white,colframe=CourseInk,sharp corners," ..
      "boxrule=.4pt,boxsep=2mm,shadow={1mm}{-1mm}{0mm}{fill=black!28}]\\Large",
      "\\end{tcolorbox}\\vspace{2mm}")
  elseif div.classes:includes("worked-output") then
    div.content = wrap(div.content, "\\par\\vspace{3mm}\\begingroup\\color{CourseGreen}", "\\endgroup\\par\\vspace{2mm}")
  elseif div.classes:includes("block") or div.classes:includes("answer-panel") then
    local colour = div.classes:includes("alert") and "CourseRed" or
      ((div.classes:includes("example") or div.classes:includes("answer-panel")) and "CourseGreen" or "CourseBlue")
    div.content = wrap(div.content,
      "\\begin{tcolorbox}[enhanced,colback=" .. colour .. "!4,colframe=" .. colour ..
      ",boxrule=.4pt,sharp corners,boxsep=1mm,left=1mm,right=1mm,top=1mm,bottom=1mm," ..
      "before skip=3mm,after skip=4mm,shadow={1mm}{-1mm}{0mm}{fill=black!28}]",
      "\\end{tcolorbox}")
  elseif div.classes:includes("small-note") then
    div.content = wrap(div.content, "{\\footnotesize", "\\par}")
  end
  return div
end

function Link(link)
  if link.classes:includes("stat-source") then
    link.content:insert(1, pandoc.RawInline("latex", "{\\scriptsize "))
    link.content:insert(pandoc.RawInline("latex", "}"))
  end
  return link
end

function Span(span)
  local command_part = span.classes:includes("command-name") and "Name" or
    (span.classes:includes("command-option") and "Option" or
    (span.classes:includes("command-operand") and "Operand" or nil))
  if command_part then
    span.content:insert(1, pandoc.RawInline("latex", "\\CourseCommandPart{" .. command_part .. "}{"))
    span.content:insert(pandoc.RawInline("latex", "}"))
  elseif span.classes:includes("marker") then
    local colour = "Green"
    if span.classes:includes("marker-plum") then colour = "Plum" end
    if span.classes:includes("marker-gold") then colour = "Gold" end
    if span.classes:includes("marker-red") then colour = "Red" end
    span.content:insert(1, pandoc.RawInline("latex", "\\CourseMarker{Marker" .. colour .. "Fill}{Marker" .. colour .. "Ink}{"))
    span.content:insert(pandoc.RawInline("latex", "}"))
  elseif span.classes:includes("stat-value") then
    span.content:insert(1, pandoc.RawInline("latex", "{\\Large\\bfseries "))
    span.content:insert(pandoc.RawInline("latex", "}"))
  elseif span.classes:includes("stat-heading") then
    span.content:insert(1, pandoc.RawInline("latex", "{\\color{CourseBlue}\\bfseries "))
    span.content:insert(pandoc.RawInline("latex", "}"))
  elseif span.classes:includes("stat-source") then
    span.content:insert(1, pandoc.RawInline("latex", "{\\scriptsize "))
    span.content:insert(pandoc.RawInline("latex", "}"))
  end
  return span
end
