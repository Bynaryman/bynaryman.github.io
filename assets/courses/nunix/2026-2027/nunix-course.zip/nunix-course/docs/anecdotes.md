# Unix names and stories

A collection of stories related to this course. Do not hesitate to contact me to suggest additions

## GNU: a name that contains itself

**GNU's Not Unix** is a recursive acronym. GNU provides a free Unix-compatible
system and tools such as Bash. [GNU FAQ](https://www.gnu.org/gnu/gnu-linux-faq.en.html).

## Unix and Multics

Unix's name plays on **Multics**, an earlier operating-system project.
Dennis Ritchie credits Brian Kernighan with suggesting it.
[Ritchie's account](https://www.nokia.com/bell-labs/about/dennis-m-ritchie/hist.html).

## Space Travel and the PDP-7

Ken Thompson moved his **Space Travel** game to a little-used PDP-7.
The tools needed to run it became part of the early work that led to Unix.
[Ritchie's account](https://www.nokia.com/bell-labs/about/dennis-m-ritchie/hist.html).

## TTY: the terminal used to be a machine

TTY means **teletype**, a physical device for sending and receiving text.
The name survives in `tty`, `/dev/tty` and the TTY column of `ps`.
[GNU terminal model](https://sourceware.org/glibc/manual/latest/html_node/Terminal-Device-Model.html),
[GNU Awk on /dev/tty](https://www.gnu.org/s/gawk/manual/html_node/Special-FD.html).

## less: moving backward through a log

Mark Nudelman needed to read the lines before an error in a large log.
His version of `more` could not move backward. The new pager was jokingly
called `less`; Nudelman no longer remembers who suggested the name.
[Author's FAQ](https://www.greenwoodsoftware.com/less/faq.html).

## grep: an editor command becomes a name

In `ed`, **g/re/p** applies a regular expression globally and prints matching
lines. `grep` makes that search available as a separate command.
[GNU grep introduction](https://www.gnu.org/software/grep/manual/grep.html).

## Pipes: connecting programs like garden hoses

In a 1964 memo, Doug McIlroy proposed connecting programs like sections of
garden hose: one program's output becomes another's input. A pipeline such as
`grep ERROR app.log | wc -l` follows this idea.
[The memo in Ritchie's archive](https://www.nokia.com/bell-labs/about/dennis-m-ritchie/mdmpipe.html).

## Bash: Bourne again

**Bourne-Again SHell** is a pun on Stephen Bourne, author of the earlier
Unix shell `sh`. Bash extends that shell's language.
[GNU Bash introduction](https://www.gnu.org/software/bash/manual/html_node/What-is-Bash_003f.html).

## #, ♯ and the shebang

`#` is called **hash** or **number sign** in English, and **croisillon** or
**carré** in French. The musical sharp sign is a different character: `♯`.
[OQLF terminology](https://vitrinelinguistique.oqlf.gouv.qc.ca/fiche-gdt/fiche/26544259/croisillon).

“Hash, bang” is a way to remember `#!`. On Linux, this first line names the
interpreter used to execute a script directly.
[Linux execve](https://man7.org/linux/man-pages/man2/execve.2.html).

## cat: concatenate

`cat` means **concatenate**. `cat a.txt b.txt` writes the contents of `a.txt`,
then `b.txt`. Reading a single file is the simplest case.
[GNU cat](https://www.gnu.org/software/coreutils/manual/html_node/cat-invocation.html).

## tar: a tape archive

`tar` means **tape archiver**. An archive collects files; compression reduces
its size. `project.tar.gz` combines both operations.
[GNU tar](https://www.gnu.org/software/tar/manual/tar.html#What-tar-Does).

## tee: picture a T-shaped pipe

A T-shaped fitting is a useful way to picture `tee`: it copies its input to
a file and standard output.
[GNU tee](https://www.gnu.org/software/coreutils/manual/html_node/tee-invocation.html).

## The deleted log that still uses disk space

Removing a file's last name does not free its storage while a process still
has it open. This can explain why `df` reports more usage than `du` can find.
[Linux unlink](https://man7.org/linux/man-pages/man2/unlink.2.html).
