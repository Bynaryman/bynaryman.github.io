# NUnix · Unix and Bash

**L3 MIAGE · ISTIC · University of Rennes**

Academic year: **2026–2027**

- **Lectures (CM):** Louis Ledoux
- **Tutorials and practical sessions (TD/TP):** Elisabeth Bouriah and Louis Ledoux

Unix/Linux commands and Bash scripting: files, permissions, processes,
redirections, pipes, variables and control flow.

## Course programme

**Three lectures of 90 minutes** in English. TD and TP worksheets are available
in French and English.

| Lecture | Topics | Application | Materials |
|---|---|---|---|
| CM1 · Understanding Unix | Shell, directories, files, paths, permissions | Locate an application's files and check access | [HTML](https://bynaryman.github.io/assets/courses/nunix/2026-2027/01-unix-shell.html) · [PDF](cours/_output/01-unix-shell.pdf) · [QMD](cours/01-unix-shell.qmd) |
| CM2 · Investigating with commands | Processes, resources, search, pipes, redirections | Find large files and count errors in a log | [HTML](https://bynaryman.github.io/assets/courses/nunix/2026-2027/02-investigation.html) · [PDF](cours/_output/02-investigation.pdf) · [QMD](cours/02-investigation.qmd) |
| CM3 · Automating with Bash | Variables, arguments, conditions, loops, functions | Write scripts with arguments and loops | [HTML](https://bynaryman.github.io/assets/courses/nunix/2026-2027/03-bash-scripting.html) · [PDF](cours/_output/03-bash-scripting.pdf) · [QMD](cours/03-bash-scripting.qmd) |

**TD exercise slides** cover file manipulation, command composition
and shell scripting.
[HTML](https://bynaryman.github.io/assets/courses/nunix/2026-2027/04-exercises.html) · [PDF](cours/_output/04-exercises.pdf) · [QMD](cours/04-exercises.qmd)

Each lecture ends with a recap and additional reference slides.

## TD and TP

The TD takes place after the three lectures. The TP covers two sessions:
commands, redirections, scripts, system information and text replacement.

| Worksheet | English | Français |
|---|---|---|
| TD1 · Shell commands | [PDF](TD/td1.pdf) · [HTML](TD/td1.html) · [QMD](TD/td1.qmd) | [PDF](TD/td1-fr.pdf) · [HTML](TD/td1-fr.html) · [QMD](TD/td1-fr.qmd) |
| TP1–2 · Commands and shell scripting | [PDF](TP/TP1-2-Unix/tp1-2.pdf) · [HTML](TP/TP1-2-Unix/tp1-2.html) · [QMD](TP/TP1-2-Unix/tp1-2.qmd) | [PDF](TP/TP1-2-Unix/tp1-2-fr.pdf) · [HTML](TP/TP1-2-Unix/tp1-2-fr.html) · [QMD](TP/TP1-2-Unix/tp1-2-fr.qmd) |

For the TP, download and extract [the files](TP/TP1-2-Unix/tp-files.zip),
then run `make` in the extracted `files` directory to build the two supplied
programs. This requires `make` and a C compiler.

## Live demo: a log report

[errors.log](cours/assets/demo/errors.log) contains 1,000 fictitious error messages.
With `a2ps` and Ghostscript (`ps2pdf`) installed, run from this repository:

```sh
cd cours/assets/demo
sort < errors.log | uniq -c | sort -nr | tee output.txt | a2ps -1 -o - | ps2pdf - rapport.pdf
```

This saves the counts in `output.txt` and creates `rapport.pdf`.

## Build and view the slides

Ready-to-use [HTML slides and PDFs](cours/_output/) are included in the repository.
The [course website](https://bynaryman.github.io/courses/nunix/) provides individual downloads.

Install [Quarto](https://quarto.org/docs/get-started/) and `make`, then run from
this directory:

```sh
make render                         # Build the four HTML decks
make all                            # Build slides, handouts and TD/TP worksheets
make worksheets                     # Build TD/TP HTML, PDFs and the TP files ZIP
make preview                        # Open CM1 with live reload
make preview DECK=02-investigation  # Open CM2
make preview DECK=03-bash-scripting # Open CM3
make preview DECK=04-exercises      # Open the exercises
```

Outputs are in `cours/_output/`. Keep that whole directory when copying HTML slides.
PDF builds require LuaLaTeX, Beamer and DejaVu fonts; handouts require Python 3,
`pypdf` and `reportlab`.

`make pdf` builds one slide per page. `make handouts` also builds **2×1, 2×2,
3×2 and 2×3** layouts on A4 landscape paper (columns × rows).
Print one PDF page per sheet.

- **Right / Space**: advance. **Left**: go back.
- **O** or **Esc**: toggle the slide overview (thumbnail grid).
- **☰**, bottom left: open the slide menu (list of titles).

## Miscellanea


[Unix names and stories](docs/anecdotes.md).
