# NUnix · Unix and Bash

**L3 MIAGE · ISTIC · University of Rennes**

Academic year: **2026–2027**

- **Lectures (CM):** Louis Ledoux
- **Tutorials and practical sessions (TD/TP):** Elisabeth Bouriah and Louis Ledoux

Unix/Linux commands and Bash scripting: files, permissions, processes,
redirections, pipes, variables and control flow.

## Course programme

**Three lectures of 90 minutes**, with course materials and exercises in English.

| Lecture | Topics | Application |
|---|---|---|
| [CM1 · Understanding Unix](cours/01-unix-shell.qmd) | Shell, directories, files, paths, permissions | Locate an application's files and check access |
| [CM2 · Investigating with commands](cours/02-investigation.qmd) | Processes, resources, search, pipes, redirections | Find large files and count errors in a log |
| [CM3 · Automating with Bash](cours/03-bash-scripting.qmd) | Variables, arguments, conditions, loops, functions | Write scripts with arguments and loops |

[Exercises](cours/04-exercises.qmd) cover file manipulation, command composition
and shell scripting.

Each lecture ends with a recap and additional reference slides.

## Build and view the slides

Ready-to-use [HTML slides and PDFs](cours/_output/) are included in the repository.
The [course website](https://bynaryman.github.io/courses/nunix/) provides individual downloads.

Install [Quarto](https://quarto.org/docs/get-started/) and `make`, then run from
this directory:

```sh
make render                         # Build the four HTML decks
make all                            # Build HTML, Beamer PDFs and print handouts
make preview                        # Open CM1 with live reload
make preview DECK=02-investigation  # Open CM2
make preview DECK=03-bash-scripting # Open CM3
make preview DECK=04-exercises      # Open the exercises
```

Outputs are in `cours/_output/`. Keep that whole directory when copying HTML slides.
PDF builds require LuaLaTeX, Beamer and DejaVu fonts; handouts require Python 3,
`pypdf` and `reportlab`.

`make pdf` builds one slide per page. `make handouts` also builds **2×1, 2×2,
3×2 and 2×3** layouts on A4 landscape paper (columns × rows).
Print one PDF page per sheet.

- **Right / Space**: advance. **Left**: go back.
- **O** or **Esc**: toggle the slide overview (thumbnail grid).
- **☰**, bottom left: open the slide menu (list of titles).

## Miscellanea


[Unix names and stories](docs/anecdotes.md).
