#!/usr/bin/env python3
"""Place vector slides on A4 landscape sheets; layout names are columns x rows.

Requires pypdf and reportlab. Run after the Beamer exports, or pass PDF paths.
The input PDFs are never modified. Slides read left to right, then top to bottom.
"""
from io import BytesIO
from math import ceil
from pathlib import Path
import argparse

from pypdf import PdfReader, PdfWriter, Transformation
import reportlab
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.units import mm
from reportlab.pdfgen.canvas import Canvas

ROOT = Path(__file__).resolve().parents[1]
LAYOUTS = ((2, 1), (2, 2), (3, 2), (2, 3))
# Embed the small header font so printer font substitution cannot distort it.
pdfmetrics.registerFont(TTFont("HandoutSans", str(Path(reportlab.__file__).parent / "fonts/Vera.ttf")))


def build(source: Path, columns: int, rows: int) -> Path:
    reader = PdfReader(source)
    writer = PdfWriter()
    width, height = landscape(A4)
    margin, gutter = 10 * mm, 5 * mm
    top, bottom = height - 18 * mm, 15 * mm
    cell_width = (width - 2 * margin - (columns - 1) * gutter) / columns
    cell_height = (top - bottom - (rows - 1) * gutter) / rows
    per_sheet = columns * rows
    count = len(reader.pages)
    title = str((reader.metadata or {}).get('/Title') or source.stem)
    for first in range(0, count, per_sheet):
        paper = writer.add_blank_page(width, height)
        decoration = BytesIO()
        canvas = Canvas(decoration, pagesize=(width, height))
        canvas.setFillColorRGB(.12, .12, .12)
        canvas.setFont('HandoutSans', 9)
        canvas.drawString(margin, height - 10 * mm, title)
        canvas.drawRightString(width - margin, height - 10 * mm,
                               f'{columns} x {rows} / slides {first + 1}-{min(first + per_sheet, count)}')
        for slot, index in enumerate(range(first, min(first + per_sheet, count))):
            slide = reader.pages[index]
            # Decks use unrotated, zero-origin pages; fail clearly for other inputs.
            assert slide.rotation == 0 and float(slide.mediabox.left) == 0 and float(slide.mediabox.bottom) == 0
            sw, sh = float(slide.mediabox.width), float(slide.mediabox.height)
            scale = min(cell_width / sw, cell_height / sh)
            x = margin + (slot % columns) * (cell_width + gutter) + (cell_width - sw * scale) / 2
            y = top - (slot // columns) * (cell_height + gutter) - cell_height + (cell_height - sh * scale) / 2
            assert x >= margin - .01 and y >= bottom - .01
            assert x + sw * scale <= width - margin + .01 and y + sh * scale <= top + .01
            paper.merge_transformed_page(slide, Transformation().scale(scale).translate(x, y))
            canvas.setStrokeColorRGB(.65, .65, .65)
            canvas.setLineWidth(.35)
            canvas.rect(x, y, sw * scale, sh * scale, stroke=1, fill=0)
        canvas.setFont('HandoutSans', 8)
        canvas.drawString(margin, 7 * mm, 'NUnix / L3 MIAGE / University of Rennes / 2026-2027')
        canvas.drawRightString(width - margin, 7 * mm,
                              f'{first // per_sheet + 1} / {ceil(count / per_sheet)}')
        canvas.save()
        paper.merge_page(PdfReader(decoration).pages[0])
        paper.compress_content_streams()
    writer.add_metadata({'/Title': f'{title} - {columns}x{rows} print handout',
                         '/Author': 'Louis Ledoux',
                         '/Subject': 'A4 landscape; columns x rows; left to right, then top to bottom'})
    output = source.with_name(f'{source.stem}-{columns}x{rows}.pdf')
    with output.open('wb') as stream:
        writer.write(stream)
    result = PdfReader(output)
    assert len(result.pages) == ceil(count / per_sheet)
    print(f'{output}: {count} slides on {len(result.pages)} A4 sheets', flush=True)
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pdfs', nargs='*', type=Path)
    args = parser.parse_args()
    sources = args.pdfs or [ROOT / 'cours/_output' / f'{deck}.pdf'
                           for deck in ('01-unix-shell', '02-investigation', '03-bash-scripting', '04-exercises')]
    for source in sources:
        for columns, rows in LAYOUTS:
            build(source, columns, rows)
